import {env} from 'cloudflare:workers';
import {handleApi} from '../../../server/payments.mjs';
import {handleAdmin,handlePresence} from '../../../server/admin.mjs';
import {drainUtmify} from '../../../server/utmify.mjs';
export const dynamic='force-dynamic';
async function handle(request:Request){
 const headers=new Headers(request.headers);
 headers.delete('oai-authenticated-user-id');
 const trusted=new Request(request.url,{method:request.method,headers,...(!['GET','HEAD'].includes(request.method)?{body:request.body}:{})});
 const path=new URL(request.url).pathname;
 const runtime={...env};
 const result=await(path.startsWith('/api/adminx/')?handleAdmin:path==='/api/presence'?handlePresence:handleApi)(trusted,runtime);
 if(result.ok&&path.startsWith('/api/adminx/'))await drainUtmify(runtime).catch(()=>{});
 return result;
}
export const GET=handle;export const POST=handle;export const PUT=handle;

import Sushi from './Sushi';
export default function Page(){return <Sushi/>}

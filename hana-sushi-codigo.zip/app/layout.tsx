import type {Metadata} from 'next';
import './sushi.css';
import {EARLY_LOCATION_SCRIPT} from './location.mjs';
export const metadata:Metadata={title:'Hana Sushi — Faça seu pedido',description:'Escolha seu combo de sushi, personalize os complementos e faça seu pedido online.',icons:{icon:'/images/logo.webp'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><head><script dangerouslySetInnerHTML={{__html:EARLY_LOCATION_SCRIPT}}/></head><body>{children}</body></html>}

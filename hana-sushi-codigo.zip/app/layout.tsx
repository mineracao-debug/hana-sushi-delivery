import type {Metadata} from 'next';
import './sushi.css';
export const metadata:Metadata={title:'Hana Sushi — Faça seu pedido',description:'Escolha seu combo de sushi, personalize os complementos e faça seu pedido online.',icons:{icon:'/images/logo.webp'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}

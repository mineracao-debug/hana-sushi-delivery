import Sushi from '../Sushi';
export default async function Page({params}:{params:Promise<{slug:string[]}>}){const {slug}=await params;return <Sushi route={slug}/>}

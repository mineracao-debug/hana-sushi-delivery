import {HttpError} from './security.mjs';
const stages=['preparing','out_for_delivery','delivered'];
export function fulfillmentView(row){
 return {
  status:row.status==='paid'?(stages.includes(row.fulfillment_status)?row.fulfillment_status:'preparing'):null,
  version:Number(row.fulfillment_version||0),
  preparingAt:row.approved_at?Number(row.approved_at):null,
  dispatchedAt:row.dispatched_at?Number(row.dispatched_at):null,
  deliveredAt:row.delivered_at?Number(row.delivered_at):null
 };
}
export async function updateFulfillment(env,row,input){
 if(row.status!=='paid')throw new HttpError('O pagamento precisa estar confirmado antes de atualizar a entrega.',409);
 const current=fulfillmentView(row),next=stages.indexOf(input?.status);
 if(!Number.isSafeInteger(input?.version)||input.version!==current.version)throw new HttpError('O pedido foi atualizado. Reabra os detalhes antes de continuar.',409);
 if(next<0)throw new HttpError('Etapa de entrega inválida.');
 if(input.status===current.status)return row;
 if(next!==stages.indexOf(current.status)+1)throw new HttpError('Siga a sequência: em preparo, saiu para entrega e entregue.',409);
 const timestamp=Date.now();
 const result=await env.DB.prepare("UPDATE orders SET fulfillment_status=?,fulfillment_version=fulfillment_version+1,dispatched_at=?,delivered_at=? WHERE id=? AND status='paid' AND fulfillment_version=?")
  .bind(input.status,next===1?timestamp:row.dispatched_at,next===2?timestamp:row.delivered_at,row.id,current.version).run();
 if(result.meta.changes!==1)throw new HttpError('O pedido foi atualizado. Reabra os detalhes antes de continuar.',409);
 return env.DB.prepare('SELECT * FROM orders WHERE id=?').bind(row.id).first();
}

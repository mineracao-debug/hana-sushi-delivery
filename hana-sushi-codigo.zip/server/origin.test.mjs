import test from 'node:test';
import assert from 'node:assert/strict';
import {sameOrigin} from './security.mjs';
const request=origin=>new Request('https://backend.example/api/adminx/login',{method:'POST',headers:origin?{Origin:origin}:{}});
test('accepts the backend and exact configured HTTPS storefront',()=>{
 const env={PUBLIC_STORE_ORIGINS:'https://store.netlify.app'};
 assert.doesNotThrow(()=>sameOrigin(request('https://backend.example'),env));
 assert.doesNotThrow(()=>sameOrigin(request('https://store.netlify.app'),env));
});
test('rejects missing, null, lookalike and unconfigured origins',()=>{
 for(const origin of [undefined,'null','https://store.netlify.app.evil.example','https://other.netlify.app','http://store.netlify.app'])
  assert.throws(()=>sameOrigin(request(origin),{PUBLIC_STORE_ORIGINS:'https://store.netlify.app'}),{status:403});
});
test('ignores wildcards, HTTP and path-bearing configuration entries',()=>{
 for(const value of ['*','http://store.netlify.app','https://store.netlify.app/path'])
  assert.throws(()=>sameOrigin(request('https://store.netlify.app'),{PUBLIC_STORE_ORIGINS:value}),{status:403});
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizePhone} from '../app/phone.mjs';

test('accepts national phones, punctuation and optional Brazil country code', () => {
  for (const phone of ['11999999999', '(11) 99999-9999', '+55 (11) 99999-9999', '55 11 99999 9999']) {
    assert.equal(normalizePhone(phone), '11999999999');
  }
  assert.equal(normalizePhone('(11) 3333-4444'), '1133334444');
  assert.equal(normalizePhone('+55 (11) 3333-4444'), '1133334444');
  assert.equal(normalizePhone('(55) 99999-9999'), '55999999999');
  assert.equal(normalizePhone('+55 (55) 99999-9999'), '55999999999');
});

test('does not invent a missing DDD or silently truncate an invalid phone', () => {
  for (const phone of ['', null, '99999-9999', '(11) 9999', '119999999999', '00000000000', 'telefone11999999999', '+1 (212) 555-1234567']) {
    assert.equal(normalizePhone(phone), '', String(phone));
  }
});

import {HttpError} from './security.mjs';
const normalized=value=>String(value||'').normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
const streetName=value=>normalized(value).replace(/^(r|rua|av|avenida|trav|travessa|al|alameda|pc|praca|estr|estrada) /,'');
const confirmationError=()=>new HttpError('Não conseguimos confirmar o endereço. Confira o nome completo da rua, bairro, cidade e estado.',422);

// Resolve only public address fields: no customer identity, house number or contact details.
export async function resolvePostalCode(address,{fetcher=fetch}={}){
 if(/^\d{8}$/.test(address.zipCode||''))return address;
 const url='https://viacep.com.br/ws/'+[address.state,address.city,address.street].map(encodeURIComponent).join('/')+'/json/';
 let data;
 try{
  const response=await fetcher(url,{signal:AbortSignal.timeout(5000),headers:{Accept:'application/json'},credentials:'omit',referrerPolicy:'no-referrer'});
  if(!response.ok)throw Error('Unavailable');data=await response.json();
 }catch{throw new HttpError('Não foi possível confirmar o endereço agora. Tente novamente em instantes.',503);}
 if(!Array.isArray(data))throw confirmationError();
 let matches=data.filter(item=>item.uf===address.state&&normalized(item.localidade)===normalized(address.city)&&streetName(item.logradouro)===streetName(address.street)&&normalized(item.bairro)===normalized(address.neighborhood)&&/^\d{5}-?\d{3}$/.test(item.cep||''));
 const number=/^\d+$/.test(address.streetNumber)?Number(address.streetNumber):null;
 const exactUnit=number===null?[]:matches.filter(item=>/^\d+$/.test(String(item.complemento||'').trim())&&Number(item.complemento)===number);
 if(exactUnit.length)matches=exactUnit;
 else matches=matches.filter(item=>!/^\d+$/.test(String(item.complemento||'').trim())&&!item.unidade);
 if(number!==null&&matches.length>1){const parity=number%2?'impar':'par';matches=matches.filter(item=>{const complement=normalized(item.complemento);return !/lado (impar|par)/.test(complement)||complement.includes('lado '+parity);});}
 const codes=[...new Set(matches.map(item=>item.cep.replace(/\D/g,'')))];
 if(codes.length!==1)throw confirmationError();
 return {...address,zipCode:codes[0]};
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {pixState,recoverPix,forgetPix,sameOrderItems} from '../app/pix-session.mjs';
const id='SB-12345678-1234-1234-1234-123456789abc';
const pending={id,amount:3490,status:'pending',qrcode:'test-only',order:{items:[{id:'1',qty:1}]}};
const get=payment=>async()=>Response.json(payment);
test('saved pending Pix is offered, never automatically rendered as the current payment',async()=>{
 const result=await recoverPix(id,{fetcher:async(url,options)=>{assert.equal(url,'/api/pix-status?id='+id);assert.equal(options.method,undefined);return Response.json(pending);}});
 assert.equal(result.kind,'offer');assert.equal(result.payment.id,id);
});
test('paid, failed, canceled, refunded and expired payments do not reopen payment',async()=>{
 for(const status of ['paid','failed','canceled','refused','refunded','chargedback','expired']){
  const result=await recoverPix(id,{fetcher:get({...pending,status})});assert.equal(result.kind,'discard',status);
 }
 assert.equal((await recoverPix(id,{fetcher:get({...pending,expirationDate:'2000-01-01T00:00:00Z'})})).kind,'discard');
 assert.equal(pixState({...pending,status:'paid',expirationDate:'2000-01-01T00:00:00Z'}),'paid');
});
test('missing expiry does not invent a payment deadline',async()=>{
 for(const expirationDate of [null,'','bad-date'])assert.equal(pixState({...pending,expirationDate}),'pending');
});
test('deleted and invalid saved IDs are discarded without creating charges',async()=>{
 assert.equal((await recoverPix('bad-id',{fetcher:()=>{throw Error('Must not fetch');}})).kind,'discard');
 for(const status of [400,403,404])assert.equal((await recoverPix(id,{fetcher:async()=>new Response('',{status})})).kind,'discard');
});
test('network errors, timeouts and unexpected responses preserve a recoverable failure',async()=>{
 await assert.rejects(recoverPix(id,{fetcher:async()=>{throw new Error('Network failure');}}));
 await assert.rejects(recoverPix(id,{fetcher:async()=>new Response('',{status:500})}));
 await assert.rejects(recoverPix(id,{fetcher:get({...pending,id:'another-order'})}));
 const controller=new AbortController();controller.abort();
 await assert.rejects(recoverPix(id,{signal:controller.signal,fetcher:async(url,{signal})=>{signal.throwIfAborted();}}),{name:'AbortError'});
});
test('finishing an old payment cannot clear a changed cart',()=>{
 assert.equal(sameOrderItems([{id:'1',qty:1}],pending),true);
 assert.equal(sameOrderItems([{id:'1',qty:2}],pending),false);
 assert.equal(sameOrderItems([{id:'2',qty:1}],pending),false);
 assert.equal(sameOrderItems([],pending),false);
 assert.equal(sameOrderItems([{id:'1',qty:1}],{...pending,order:null}),false);
});
test('clearing old payment recovery does not remove a newer payment saved by another tab',()=>{
 let saved='newer';const storage={getItem:()=>saved,removeItem:()=>{saved=null;}};
 forgetPix(storage,id);assert.equal(saved,'newer');saved=id;forgetPix(storage,id);assert.equal(saved,null);
});

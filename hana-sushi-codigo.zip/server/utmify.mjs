export const UTMIFY_URL='https://api.utmify.com.br/api-credentials/orders';
const fields=['src','sck','utm_source','utm_campaign','utm_medium','utm_content','utm_term'];
export function cleanTracking(value){
 return Object.fromEntries(fields.map(key=>[key,typeof value?.[key]==='string'?value[key].replace(/[\u0000-\u001f\u007f]/g,'').slice(0,500)||null:null]));
}
const statuses={pending:'waiting_payment',paid:'paid',refused:'refused',canceled:'refused',refunded:'refunded',chargedback:'chargedback'};
const date=value=>value?new Date(Number(value)).toISOString().slice(0,19).replace('T',' '):null;
export function utmifyPayload(row){
 const details=typeof row.details==='string'?JSON.parse(row.details):row.details;
 // Merchant reconciles fees inside UTMify: export gross revenue with no fee deduction.
 // Actual gateway fees remain stored separately on the order.
 const fee=0;
 if(!statuses[row.status])return null;
 return {
  orderId:row.id,platform:'HanaSushi',paymentMethod:'pix',status:statuses[row.status],
  createdAt:date(row.created_at),approvedDate:date(row.approved_at),refundedAt:date(row.refunded_at),
  customer:{name:details.customer.name,email:details.customer.email,phone:details.customer.phone,
   document:details.customer.document.number,country:'BR',...(details.clientIp?{ip:details.clientIp}:{})},
  products:details.items.map(item=>({id:item.externalRef,name:item.title,planId:null,planName:null,quantity:item.quantity,priceInCents:item.unitPrice})),
  trackingParameters:cleanTracking(details.tracking),
  commission:{totalPriceInCents:row.amount,gatewayFeeInCents:fee,userCommissionInCents:row.amount-fee,currency:'BRL'},
  isTest:false
 };
}
export async function sendUtmify(token,payload,fetcher=fetch){
 const response=await fetcher(UTMIFY_URL,{method:'POST',headers:{'Content-Type':'application/json','x-api-token':token},body:JSON.stringify(payload),signal:AbortSignal.timeout(8000)});
 let result;try{result=await response.json();}catch{throw new Error('UTMIFY_INVALID_RESPONSE');}
 if(!response.ok||result?.error||result?.success===false||result?.ok===false||result?.OK===false)throw new Error('UTMIFY_REJECTED_'+response.status);
 return result;
}
export async function deliverUtmify(env,id){
 if(!env.UTMIFY_API_TOKEN)return false;
 const now=Date.now(),lease=now+120000;
 const claimed=await env.DB.prepare("UPDATE orders SET utmify_lock_until=? WHERE id=? AND utmify_lock_until<=? AND utmify_next_attempt<=? AND status IN ('pending','paid','refused','canceled','refunded','chargedback') AND (utmify_sent_status IS NULL OR utmify_sent_status<>status)").bind(lease,id,now,now).run();
 if(claimed.meta.changes!==1)return false;
 const row=await env.DB.prepare('SELECT * FROM orders WHERE id=?').bind(id).first();
 let success=false;
 try{
  const payload=utmifyPayload(row);
  if(!payload)throw new Error('UTMIFY_WAITING_GATEWAY_FEE');
  await sendUtmify(env.UTMIFY_API_TOKEN,payload,env.__utmifyFetch||fetch);
  await env.DB.prepare('UPDATE orders SET utmify_sent_status=?,utmify_attempts=0,utmify_next_attempt=0,utmify_lock_until=0 WHERE id=? AND utmify_lock_until=?').bind(row.status,id,lease).run();
  success=true;
 }catch{
  const attempts=Number(row.utmify_attempts)+1;
  const retry=Date.now()+Math.min(3600000,60000*2**Math.min(attempts-1,6));
  await env.DB.prepare('UPDATE orders SET utmify_attempts=?,utmify_next_attempt=?,utmify_lock_until=0 WHERE id=? AND utmify_lock_until=?').bind(attempts,retry,id,lease).run();
 }
 return success;
}
// Start delivery as soon as the order changes. Netlify keeps this task alive
// after returning the checkout/webhook response; the scheduled queue is a fallback.
export async function notifyUtmify(env,id){
 if(!env.UTMIFY_API_TOKEN||!env.DB)return;
 const task=(async()=>{
  // A payment can be confirmed while waiting_payment is still being delivered.
  // Send the newer state immediately after releasing the lease, in order.
  for(let state=0;state<3;state++)if(!await deliverUtmify(env,id))break;
 })().catch(()=>false);
 if(typeof env.waitUntil==='function'){
  try{env.waitUntil(task);return;}catch{/* Fall back to awaiting if the host cannot retain the task. */}
 }
 await task;
}
export async function drainUtmify(env){
 if(!env.UTMIFY_API_TOKEN||!env.DB)return {sent:0,attempted:0};
 const now=Date.now();
 const {results}=await env.DB.prepare("SELECT id FROM orders WHERE status IN ('pending','paid','refused','canceled','refunded','chargedback') AND (utmify_sent_status IS NULL OR utmify_sent_status<>status) AND utmify_lock_until<=? AND utmify_next_attempt<=? ORDER BY utmify_next_attempt,created_at LIMIT 10").bind(now,now).all();
 const delivered=await Promise.all(results.map(row=>deliverUtmify(env,row.id)));
 return {sent:delivered.filter(Boolean).length,attempted:results.length};
}

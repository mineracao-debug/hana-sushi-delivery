import test from 'node:test';
import assert from 'node:assert/strict';
import {cepDigits,formatCEP,lookupCEP,createCEPLookup} from '../app/cep.mjs';
const address={cep:'01001-000',logradouro:'Praça da Sé',bairro:'Sé',localidade:'São Paulo',uf:'SP'};

test('CEP formats pasted digits and refuses incomplete requests',async()=>{
 assert.equal(formatCEP('01001000'),'01001-000');
 assert.equal(formatCEP('01001-000'),'01001-000');
 assert.equal(formatCEP('010'),'010');assert.equal(cepDigits('01001-000'),'01001000');
 let called=false;await assert.rejects(()=>lookupCEP('0100',{fetchImpl:()=>{called=true;}}),e=>e.code==='invalid');assert.equal(called,false);
});
test('CEP lookup fills an address without sending contact data or cookies',async()=>{
 const result=await lookupCEP('01001-000',{fetchImpl:async(url,options)=>{
  assert.equal(url,'https://viacep.com.br/ws/01001000/json/');assert.equal(options.credentials,'omit');assert.equal(options.referrerPolicy,'no-referrer');
  return Response.json(address);
 }});
 assert.deepEqual(result,{street:'Praça da Sé',district:'Sé',city:'São Paulo',uf:'SP'});
 const cityOnly=await lookupCEP('01001000',{fetchImpl:async()=>Response.json({...address,logradouro:'',bairro:''})});
 assert.equal(cityOnly.street,'');assert.equal(cityOnly.city,'São Paulo');
});
test('CEP not found and service failures have a manual-address fallback',async()=>{
 for(const erro of [true,'true'])await assert.rejects(()=>lookupCEP('99999999',{fetchImpl:async()=>Response.json({erro})}),e=>e.code==='not_found');
 for(const fetchImpl of [async()=>new Response('',{status:503}),async()=>Response.json({...address,cep:'20040-002'}),async()=>{throw new Error('offline');}]){
  await assert.rejects(()=>lookupCEP('01001000',{fetchImpl}),e=>e.code==='unavailable');
 }
 await assert.rejects(()=>lookupCEP('01001000',{timeoutMs:5,fetchImpl:(_url,{signal})=>new Promise((_resolve,reject)=>signal.addEventListener('abort',()=>reject(new Error('timeout'))))}),e=>e.code==='unavailable');
});
test('a delayed old CEP cannot overwrite a newer address',async()=>{
 const pending=new Map();const client=createCEPLookup((cep,{signal})=>new Promise(resolve=>pending.set(cep,{resolve,signal})));
 const first=client.lookup('01001000');const second=client.lookup('20040002');assert.equal(pending.get('01001000').signal.aborted,true);
 pending.get('20040002').resolve({city:'Rio de Janeiro'});assert.deepEqual(await second,{city:'Rio de Janeiro'});
 pending.get('01001000').resolve({city:'São Paulo'});assert.equal(await first,null);
});
test('manual address editing cancels late CEP results and errors',async()=>{
 let resolve;const client=createCEPLookup(()=>new Promise(done=>{resolve=done;}));const promise=client.lookup('01001000');client.cancel();resolve(address);assert.equal(await promise,null);
 let reject;const failed=createCEPLookup(()=>new Promise((_done,no)=>{reject=no;}));const stale=failed.lookup('01001000');failed.cancel();reject(new Error('offline'));assert.equal(await stale,null);
});

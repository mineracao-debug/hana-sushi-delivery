import test from 'node:test';
import assert from 'node:assert/strict';
import {resolvePostalCode} from './address.mjs';
import {handleApi,validateOrder} from './payments.mjs';
import {localDB} from './local-db.mjs';
const address={street:'Praça da Sé',streetNumber:'1',neighborhood:'Sé',city:'São Paulo',state:'SP',country:'BR',zipCode:''};
const match={logradouro:'Praça da Sé',bairro:'Sé',localidade:'São Paulo',uf:'SP',cep:'01001-000'};
const body=()=>({lines:[{id:'1',qty:1}],customer:{name:'Cliente Teste',email:'cliente@example.com',cpf:'52998224725',phone:'11999999999'},ship:'entrega',address:{street:address.street,number:address.streetNumber,district:address.neighborhood,city:address.city,uf:address.state}});
test('delivery address accepts checkout without CEP and resolves only the matching street and district',async()=>{
 assert.equal(validateOrder(body()).address.zipCode,'');
 const result=await resolvePostalCode(address,{fetcher:async(url,options)=>{assert.equal(url,'https://viacep.com.br/ws/SP/S%C3%A3o%20Paulo/Pra%C3%A7a%20da%20S%C3%A9/json/');assert.equal(options.credentials,'omit');assert.equal(options.body,undefined);return Response.json([match,{...match,bairro:'Outro bairro',cep:'01002-000'}]);}});
 assert.equal(result.zipCode,'01001000');assert.equal(result.streetNumber,'1');
});
test('accent and street-prefix variations match, explicit parity resolves street sides',async()=>{
 const odd={...match,complemento:'lado ímpar'},even={...match,cep:'01001-001',complemento:'lado par'},unit={...match,cep:'01001-901',complemento:'371',unidade:'Edifício de teste'};
 assert.equal((await resolvePostalCode({...address,street:'Praca da Se',neighborhood:'Se'},{fetcher:async()=>Response.json([odd,even,unit])})).zipCode,'01001000');
 assert.equal((await resolvePostalCode({...address,streetNumber:'371'},{fetcher:async()=>Response.json([odd,even,unit])})).zipCode,'01001901');
 assert.equal((await resolvePostalCode({...address,streetNumber:'2'},{fetcher:async()=>Response.json([odd,even])})).zipCode,'01001001');
});
test('unknown, different-city and ambiguous addresses are rejected before any charge',async()=>{
 for(const data of [[],{},[{...match,uf:'BA'}],[{...match,localidade:'Outra cidade'}],[match,{...match,cep:'01002-000'}]])await assert.rejects(resolvePostalCode(address,{fetcher:async()=>Response.json(data)}),error=>error.status===422);
 await assert.rejects(resolvePostalCode(address,{fetcher:async()=>{throw Error('Network unavailable');}}),error=>error.status===503);
});
test('a no-CEP checkout sends a resolved postal code to Sharkpay; retry reuses charge without another lookup',async()=>{
 let addressCalls=0,payments=0;
 const env={DB:localDB(),SHARKPAY_API_KEY:'test-only',__addressFetch:async()=>{addressCalls++;return Response.json([match]);},__fetch:async(url,options)=>{payments++;const payment=JSON.parse(options.body);assert.equal(payment.delivery.address.zipCode,'01001000');assert.equal(payment.delivery.address.street,'Praça da Sé');return Response.json({id:'test-no-cep',amount:2990,currency:'BRL',method:'PIX',status:'PENDING',data:{}});}};
 try{
  await env.DB.prepare('INSERT INTO shop_settings (id,value,version) VALUES (1,?,1)').bind(JSON.stringify({active:'sharkpay',credentials:{},pickupAddress:null})).run();
  const config=await handleApi(new Request('http://127.0.0.1:4173/api/checkout-config'),env),cookie=config.headers.get('Set-Cookie').split(';')[0];
  const create=()=>handleApi(new Request('http://127.0.0.1:4173/api/pix',{method:'POST',headers:{Origin:'http://127.0.0.1:4173','Content-Type':'application/json',Cookie:cookie,'Idempotency-Key':'no-cep-request-0001'},body:JSON.stringify(body())}),env);
  const first=await create();assert.equal(first.status,202);const order=await first.json();
  const duplicate=await create();assert.equal((await duplicate.json()).id,order.id);assert.equal(payments,1);assert.equal(addressCalls,1);
  const saved=await env.DB.prepare('SELECT details FROM orders WHERE id=?').bind(order.id).first();assert.equal(JSON.parse(saved.details).address.zipCode,'01001000');
 }finally{env.DB.close();}
});
test('lookup failure creates neither order nor gateway payment',async()=>{
 const env={DB:localDB(),UMBRELLAPAG_API_KEY:'test-only',__addressFetch:async()=>Response.json([]),__fetch:()=>{throw Error('Must not create payment');}};
 try{
  const result=await handleApi(new Request('http://127.0.0.1:4173/api/pix',{method:'POST',headers:{Origin:'http://127.0.0.1:4173','Content-Type':'application/json','Idempotency-Key':'unmatched-request-0001'},body:JSON.stringify(body())}),env);
  assert.equal(result.status,422);assert.equal((await env.DB.prepare('SELECT COUNT(*) AS count FROM orders').first()).count,0);
 }finally{env.DB.close();}
});

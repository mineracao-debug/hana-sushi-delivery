import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {localDB} from './local-db.mjs';
import {validateOrder,handleApi} from './payments.mjs';
import {handleAdmin,handlePresence} from './admin.mjs';
import {token,passwordHash} from './security.mjs';
import products from './products.json' with {type:'json'};
const origin='https://sushi.example';
const req=(path,method='GET',body,user)=>new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json',...(user?{'oai-authenticated-user-id':user}:{})},...(body?{body:JSON.stringify(body)}:{})});
const order=()=>({lines:[{id:'1',qty:1}],customer:{name:'Cliente Teste',email:'test@example.com',cpf:'52998224725',phone:'11999999999'},ship:'retirada'});
test('all customer and server prices match and every product image exists',()=>{
 const catalog=JSON.parse(readFileSync('public/data/catalog.json','utf8'));assert.equal(products.length,19);
 for(const p of products){assert.equal(p.price,catalog[p.id].price);assert.ok(existsSync('public'+catalog[p.id].image),p.title);}
});
test('sushi additions and one gift use authoritative catalog amounts',()=>{
 const body=order();body.lines.push({id:'tare',qty:2},{id:'gift-chocolate',qty:1});const result=validateOrder(body);assert.equal(result.amount,3770);assert.equal(result.shipping,0);
 body.lines.push({id:'gift-doce',qty:1});assert.throws(()=>validateOrder(body),/uma sobremesa/);
 assert.throws(()=>validateOrder({...order(),lines:[{id:'tare',qty:1}]}),/combo/);
 assert.throws(()=>validateOrder({...order(),lines:[{id:'1',qty:1},{id:'tare',qty:3},{id:'cream',qty:3}]}),/cinco/);
});
test('checkout fails closed without payment credentials',async()=>{const env={DB:localDB()};const r=await handleApi(req('/api/checkout-config'),env);assert.equal((await r.json()).pixEnabled,false);env.DB.close();});
test('admin uses password sessions, rejects ChatGPT identities, and revokes logout',async()=>{
 const env={DB:localDB(),ADMIN_USERNAME:'adminx',ADMIN_PASSWORD_HASH:await passwordHash('test-password'),SETTINGS_ENCRYPTION_KEY:token()};
 assert.equal((await handleAdmin(req('/api/adminx/session'),env)).status,401);
 assert.equal((await handleAdmin(req('/api/adminx/activate','POST',{},'owner'),env)).status,401);
 assert.equal((await handleAdmin(req('/api/adminx/orders','GET',null,'owner'),env)).status,401);
 assert.equal((await handleAdmin(req('/api/adminx/login','POST',{username:'adminx',password:'wrong'}),env)).status,401);
 const login=await handleAdmin(req('/api/adminx/login','POST',{username:'adminx',password:'test-password'}),env);
 assert.equal(login.status,200);const cookie=login.headers.get('Set-Cookie');assert.match(cookie,/HttpOnly/);assert.match(cookie,/Secure/);assert.match(cookie,/SameSite=Strict/);
 const signed=(path,method='GET')=>{const request=req(path,method,method==='POST'?{}:undefined);request.headers.set('Cookie',cookie.split(';')[0]);return request;};
 const summary=await handleAdmin(signed('/api/adminx/summary'),env);assert.equal(summary.status,200);assert.equal((await summary.json()).totals.revenue,0);
 const crossOrigin=signed('/api/adminx/logout','POST');crossOrigin.headers.set('Origin','https://evil.example');assert.equal((await handleAdmin(crossOrigin,env)).status,403);
 assert.equal((await handleAdmin(signed('/api/adminx/logout','POST'),env)).status,200);
 assert.equal((await handleAdmin(signed('/api/adminx/session'),env)).status,401);
 env.DB.close();
});
test('presence tracks a sushi cart without accepting client pricing',async()=>{
 const env={DB:localDB(),SETTINGS_ENCRYPTION_KEY:token()};const r=await handlePresence(req('/api/presence','POST',{path:'/cart/',stage:'cart',cart:[{id:'1',qty:2,price:1}],tracking:{utm_source:'test'}}),env);assert.equal(r.status,200);
 const row=await env.DB.prepare('SELECT * FROM online_visitors').first();assert.equal(row.cart_value,5980);assert.equal(row.stage,'cart');env.DB.close();
});

// Small adapter for the shared payment service. Only application-owned SQL
// templates reach this adapter; all visitor input stays in bound parameters.
export function postgresDB(pool){
 return {prepare(sql){
  let values=[];
  function statement(){
   let number=0;
   let query=sql.replace(/\?/g,()=>'$'+(++number));
   if(/^INSERT OR IGNORE /i.test(query))query=query.replace(/^INSERT OR IGNORE /i,'INSERT ')+' ON CONFLICT DO NOTHING';
   return query;
  }
  return {
   bind(...parameters){values=parameters;return this;},
   async first(){return (await pool.query(statement(),values)).rows[0]||null;},
   async all(){return {results:(await pool.query(statement(),values)).rows};},
   async run(){const result=await pool.query(statement(),values);return {meta:{changes:result.rowCount??result.affectedRows??0},success:true};}
  };
 }};
}

import {seal,unseal,HttpError} from './security.mjs';
export const providers=['umbrellapag','sharkpay'];
export async function settings(env){const row=await env.DB.prepare('SELECT value,version FROM shop_settings WHERE id=1').first();return {value:row?JSON.parse(row.value):{active:'umbrellapag',credentials:{},sharkFee:null,pickupAddress:null},version:row?.version||0};}
export async function credential(env,provider,id){
 if(id){const row=await env.DB.prepare('SELECT secret FROM gateway_credentials WHERE id=? AND provider=?').bind(id,provider).first();if(!row)throw new Error('GATEWAY_CREDENTIAL_MISSING');return unseal(env,row.secret,provider+':'+id);}
 return provider==='umbrellapag'?env.UMBRELLAPAG_API_KEY:env.SHARKPAY_API_KEY;
}
export async function activeGateway(env){const {value}=await settings(env);const provider=value.active,credentialId=value.credentials?.[provider]||null;return {provider,credentialId,key:await credential(env,provider,credentialId),settings:value};}
export async function publicSettings(env){
 const {value,version}=await settings(env);const gateways={};
 for(const provider of providers){const secret=await credential(env,provider,value.credentials?.[provider]);gateways[provider]={configured:!!secret,ending:secret?secret.slice(-4):null};}
 return {active:value.active,gateways,version,sharkFee:value.sharkFee||null,pickupAddress:value.pickupAddress||null,utmifyConfigured:!!env.UTMIFY_API_TOKEN,productDescription:'Produto físico'};
}
function address(value){if(value==null)return null;const result={};for(const field of ['street','streetNumber','zipCode','neighborhood','city','state']){if(typeof value[field]!=='string'||!value[field].trim()||value[field].length>150)throw new HttpError('Preencha o endereço completo de retirada.');result[field]=value[field].trim();}result.zipCode=result.zipCode.replace(/\D/g,'');if(!/^\d{8}$/.test(result.zipCode)||!/^[A-Z]{2}$/.test(result.state))throw new HttpError('CEP ou UF de retirada inválidos.');result.country='BR';result.complement=String(value.complement||'').slice(0,100);return result;}
export async function saveSettings(env,input,validateCredential){
 const current=await settings(env);if(input.version!==current.version)throw new HttpError('As configurações mudaram. Atualize a página e tente novamente.',409);
 if(!providers.includes(input.active))throw new HttpError('Escolha uma operadora válida.');
 const next={...current.value,active:input.active,credentials:{...current.value.credentials}};
 if(input.sharkFee!==undefined){const fee=input.sharkFee;if(fee!==null&&(!Number.isInteger(fee.fixed)||fee.fixed<0||fee.fixed>100000||!Number.isInteger(fee.bps)||fee.bps<0||fee.bps>10000))throw new HttpError('Informe a taxa contratada corretamente.');next.sharkFee=fee;}
 if(input.pickupAddress!==undefined)next.pickupAddress=address(input.pickupAddress);
 // New credentials are validated read-only and versioned. Existing orders keep their old key.
 for(const provider of providers){const secret=input.keys?.[provider];if(secret===undefined||secret==='')continue;if(typeof secret!=='string'||secret.length<8||secret.length>2048||/[\s\x00-\x1f]/.test(secret))throw new HttpError('Chave inválida. Cole somente a chave, sem espaços.');await validateCredential(env,provider,secret);const id=crypto.randomUUID();await env.DB.prepare('INSERT INTO gateway_credentials (id,provider,secret,created_at) VALUES (?,?,?,?)').bind(id,provider,seal(env,secret,provider+':'+id),Date.now()).run();next.credentials[provider]=id;}
 const activeKey=await credential(env,next.active,next.credentials[next.active]);if(!activeKey)throw new HttpError('Cadastre a chave da operadora antes de ativá-la.');
 if(next.active!==current.value.active)await validateCredential(env,next.active,activeKey);
 const changed=current.version?await env.DB.prepare('UPDATE shop_settings SET value=?,version=version+1 WHERE id=1 AND version=?').bind(JSON.stringify(next),current.version).run():await env.DB.prepare('INSERT OR IGNORE INTO shop_settings (id,value,version) VALUES (1,?,1)').bind(JSON.stringify(next)).run();
 if(changed.meta.changes!==1)throw new HttpError('As configurações mudaram. Atualize a página e tente novamente.',409);
 // Fees entered after a test unblock only orders whose fee is still unknown.
 if(next.sharkFee)await env.DB.prepare("UPDATE orders SET fee_cents=CAST(ROUND(amount*?/10000.0)+? AS INTEGER),utmify_next_attempt=0 WHERE provider='sharkpay' AND fee_cents IS NULL AND ROUND(amount*?/10000.0)+?<=amount").bind(next.sharkFee.bps,next.sharkFee.fixed,next.sharkFee.bps,next.sharkFee.fixed).run();
 await env.DB.prepare('INSERT INTO admin_audit (id,action,created_at) VALUES (?,?,?)').bind(crypto.randomUUID(),'gateway_settings_updated:'+next.active,Date.now()).run();
 return publicSettings(env);
}

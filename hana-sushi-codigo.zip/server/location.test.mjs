import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {normalizeLocation,readLocation,saveLocation,detectCity,LOCATION_MAX_AGE,LOCATION_TIMEOUT,EARLY_LOCATION_SCRIPT} from '../app/location.mjs';
test('location accepts Brazilian city and UF without collecting IP or coordinates',()=>{
 assert.deepEqual(normalizeLocation({country_code:'BR',region_code:'BR-BA',city:'Valença',ip:'ignored',latitude:1}),{city:'Valença',state:'BA'});
 for(const data of [{country_code:'US',region_code:'CA',city:'Los Angeles'},{country_code:'BR',region_code:'XX',city:'Valença'},{country_code:'BR',region_code:'BA',city:'<script>'}])assert.equal(normalizeLocation(data),null);
});
test('automatic selection expires; manual correction persists',()=>{
 let raw;const storage={getItem:()=>raw,setItem:(_,v)=>raw=v};
 const auto=saveLocation(storage,{city:'São Paulo',state:'SP'},'auto');
 assert.equal(readLocation(storage,auto.savedAt+1000).city,'São Paulo');
 assert.equal(readLocation(storage,auto.savedAt+LOCATION_MAX_AGE),null);
 const manual=saveLocation(storage,{city:'Valença',state:'BA'},'manual');
 assert.equal(readLocation(storage,manual.savedAt+LOCATION_MAX_AGE*50).city,'Valença');
 raw='{';assert.equal(readLocation(storage),null);
});
test('unavailable storage does not prevent detection or correction',()=>{
 const storage={getItem:()=>{throw Error();},setItem:()=>{throw Error();}};
 assert.equal(readLocation(storage),null);assert.equal(saveLocation(storage,{city:'Valença',state:'BA'},'manual').city,'Valença');
});
test('detector uses visitor browser IP, no cookies or precise coordinates',async()=>{
 const location=await detectCity({fetchImpl:async(url,options)=>{
  assert.match(url,/^https:\/\/ipwho.is\/\?/);assert.equal(options.credentials,'omit');assert.equal(options.referrerPolicy,'no-referrer');
  return Response.json({success:true,country_code:'BR',region_code:'BA',city:'Valença'});
 }});assert.deepEqual(location,{city:'Valença',state:'BA'});
});
test('rate limits, service errors and non-Brazilian results fall back without inventing a city',async()=>{
 for(const response of [new Response('',{status:429}),Response.json({success:false}),Response.json({success:true,country_code:'US',region_code:'CA',city:'Los Angeles'})])await assert.rejects(detectCity({fetchImpl:async()=>response}));
});
test('early lookup starts before the app and is reused without a duplicate request',async()=>{
 let calls=0,timeout;
 const window={location:{pathname:'/'}};
 vm.runInNewContext(EARLY_LOCATION_SCRIPT,{window,localStorage:{getItem:()=>null},AbortSignal:{timeout:ms=>{timeout=ms;return AbortSignal.timeout(ms);}},fetch:async()=>{calls++;return Response.json({success:true,country_code:'BR',region_code:'BA',city:'Valença'});}});
 assert.equal(calls,1);assert.equal(timeout,LOCATION_TIMEOUT);assert.equal(timeout,3000);
 const location=await detectCity({earlyRequest:window.__hanaLocationRequest,fetchImpl:()=>{throw Error('Duplicate request');}});
 assert.deepEqual(location,{city:'Valença',state:'BA'});
});
test('early lookup skips valid saved locations and non-home pages',()=>{
 for(const [pathname,saved] of [['/checkout/',null],['/',{city:'Valença',state:'BA',source:'manual'}],['/',{city:'Valença',state:'BA',source:'auto',savedAt:Date.now()}]]){
  const window={location:{pathname}};
  vm.runInNewContext(EARLY_LOCATION_SCRIPT,{window,localStorage:{getItem:()=>JSON.stringify(saved)},fetch:()=>{throw Error('Unnecessary request');},AbortSignal});
  assert.equal(window.__hanaLocationRequest,undefined);
 }
});
test('early lookup works when storage is blocked and expired cache does not suppress detection',async()=>{
 for(const storage of [{getItem:()=>{throw Error('Blocked');}},{getItem:()=>JSON.stringify({city:'Valença',state:'BA',source:'auto',savedAt:Date.now()-LOCATION_MAX_AGE})}]){
  const window={location:{pathname:'/'}};
  vm.runInNewContext(EARLY_LOCATION_SCRIPT,{window,localStorage:storage,AbortSignal,fetch:async()=>Response.json({success:true,country_code:'BR',region_code:'SP',city:'São Paulo'})});
  assert.equal((await detectCity({earlyRequest:window.__hanaLocationRequest})).state,'SP');
 }
});
test('a cancelled selection ignores an early response',async()=>{
 const controller=new AbortController();controller.abort();
 await assert.rejects(detectCity({signal:controller.signal,earlyRequest:Promise.resolve({success:true,country_code:'BR',region_code:'BA',city:'Valença'})}));
});

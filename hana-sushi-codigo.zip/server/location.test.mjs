import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeLocation,readLocation,saveLocation,detectCity,LOCATION_MAX_AGE} from '../app/location.mjs';
test('location accepts Brazilian city and UF without collecting IP or coordinates',()=>{
 assert.deepEqual(normalizeLocation({country_code:'BR',region_code:'BR-BA',city:'Valença',ip:'ignored',latitude:1}),{city:'Valença',state:'BA'});
 for(const data of [{country_code:'US',region_code:'CA',city:'Los Angeles'},{country_code:'BR',region_code:'XX',city:'Valença'},{country_code:'BR',region_code:'BA',city:'<script>'}])assert.equal(normalizeLocation(data),null);
});
test('automatic selection expires; manual correction persists',()=>{
 let raw;const storage={getItem:()=>raw,setItem:(_,v)=>raw=v};
 const auto=saveLocation(storage,{city:'São Paulo',state:'SP'},'auto');
 assert.equal(readLocation(storage,auto.savedAt+1000).city,'São Paulo');
 assert.equal(readLocation(storage,auto.savedAt+LOCATION_MAX_AGE),null);
 const manual=saveLocation(storage,{city:'Valença',state:'BA'},'manual');
 assert.equal(readLocation(storage,manual.savedAt+LOCATION_MAX_AGE*50).city,'Valença');
 raw='{';assert.equal(readLocation(storage),null);
});
test('unavailable storage does not prevent detection or correction',()=>{
 const storage={getItem:()=>{throw Error();},setItem:()=>{throw Error();}};
 assert.equal(readLocation(storage),null);assert.equal(saveLocation(storage,{city:'Valença',state:'BA'},'manual').city,'Valença');
});
test('detector uses visitor browser IP, no cookies or precise coordinates',async()=>{
 const location=await detectCity({fetchImpl:async(url,options)=>{
  assert.match(url,/^https:\/\/ipwho.is\/\?/);assert.equal(options.credentials,'omit');assert.equal(options.referrerPolicy,'no-referrer');
  return Response.json({success:true,country_code:'BR',region_code:'BA',city:'Valença'});
 }});assert.deepEqual(location,{city:'Valença',state:'BA'});
});
test('rate limits, service errors and non-Brazilian results fall back without inventing a city',async()=>{
 for(const response of [new Response('',{status:429}),Response.json({success:false}),Response.json({success:true,country_code:'US',region_code:'CA',city:'Los Angeles'})])await assert.rejects(detectCity({fetchImpl:async()=>response}));
});

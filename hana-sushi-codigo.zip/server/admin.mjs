import {json,HttpError,sameOrigin,bodyJson,passwordMatches,sha,token,equal,rateLimit,sign} from './security.mjs';
import {publicSettings,saveSettings} from './gateway-settings.mjs';
import {validateCredential} from './gateways.mjs';
import {refreshOrder} from './payments.mjs';
import {recordVisit,visitorReport} from './visitor-funnel.mjs';
import {fulfillmentView,updateFulfillment} from './fulfillment.mjs';
const statuses=['creating','review','pending','paid','failed','refused','canceled','refunded','chargedback'];
const lifetime=8*3600000;
const cookie=(request,value,age=lifetime/1000)=>`sheik_admin=${value}; Path=/api/adminx; HttpOnly; SameSite=Strict; Max-Age=${age}${new URL(request.url).protocol==='https:'?'; Secure':''}`;
const cookieToken=request=>request.headers.get('Cookie')?.match(/(?:^|;\s*)sheik_admin=([a-f0-9]{64})(?:;|$)/)?.[1];
async function authenticated(request,env){const value=cookieToken(request);if(!value)return false;const row=await env.DB.prepare('SELECT auth_version,expires_at FROM admin_sessions WHERE token_hash=?').bind(sha(value)).first();return row&&Number(row.expires_at)>Date.now()&&equal(row.auth_version,sha(env.ADMIN_PASSWORD_HASH));}
function range(url){const days=Number(url.searchParams.get('days')||7);if(![1,7,30,90].includes(days))throw new HttpError('Período inválido.');return Date.now()-days*86400000;}
function orderView(row,detail=false){const d=JSON.parse(row.details);return {id:row.id,fulfillment:fulfillmentView(row),parentOrderId:row.parent_order_id||null,rootOrderId:row.root_order_id||row.id,createdAt:Number(row.created_at),amount:row.amount,status:row.status,provider:row.provider,providerStatus:row.provider_status,customer:{name:d.customer.name,...(detail?{email:d.customer.email,phone:d.customer.phone,document:d.customer.document.number}:{})},tracking:d.tracking||{},utmify:{sentStatus:row.utmify_sent_status,attempts:row.utmify_attempts,waitingFee:false},...(detail?{items:d.items,address:d.address||null,ship:d.ship,subtotal:d.subtotal,shipping:d.shipping,fee:row.fee_cents,feeSource:row.provider==='sharkpay'?'Taxa contratada informada no painel':'Informada pela operadora',providerId:row.provider_id,approvedAt:row.approved_at?Number(row.approved_at):null}:{})};}
async function orderDetail(env,row){
 const root=row.root_order_id||row.id;
 const [group,total]=await Promise.all([
  env.DB.prepare('SELECT id,parent_order_id,amount,status,created_at FROM orders WHERE id=? OR root_order_id=? ORDER BY created_at DESC,id DESC LIMIT 100').bind(root,root).all(),
  env.DB.prepare("SELECT COUNT(*) AS count,COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) AS paid FROM orders WHERE id=? OR root_order_id=?").bind(root,root).first()
 ]);
 return {...orderView(row,true),purchaseGroup:{count:Number(total.count),paidTotal:Number(total.paid),orders:group.results.map(o=>({id:o.id,parentOrderId:o.parent_order_id||null,amount:o.amount,status:o.status,createdAt:Number(o.created_at)}))}};
}
export async function handleAdmin(request,env){
 try{
  if(!env.DB||!env.ADMIN_PASSWORD_HASH||!env.SETTINGS_ENCRYPTION_KEY)throw new HttpError('O painel ainda não está configurado.',503);
  const url=new URL(request.url),path=url.pathname;
  if(!['GET','HEAD'].includes(request.method))sameOrigin(request,env);
  if(path==='/api/adminx/login'&&request.method==='POST'){
   const ip=request.headers.get('CF-Connecting-IP')||'local';
   const limited=await rateLimit(env.DB,'login:'+sha(ip),6,900000),global=await rateLimit(env.DB,'login:global',60,900000);
   if(!limited||!global)throw new HttpError('Muitas tentativas. Aguarde 15 minutos.',429);
   const body=await bodyJson(request,2048);
   const valid=typeof body.password==='string'&&body.password.length<=256&&await passwordMatches(body.password,env.ADMIN_PASSWORD_HASH);
   if(!valid||!equal(body.username,env.ADMIN_USERNAME||'adminx'))throw new HttpError('Usuário ou senha incorretos.',401);
   const value=token();await env.DB.prepare('DELETE FROM admin_sessions WHERE expires_at<?').bind(Date.now()).run();
   await env.DB.prepare('INSERT INTO admin_sessions (token_hash,auth_version,expires_at) VALUES (?,?,?)').bind(sha(value),sha(env.ADMIN_PASSWORD_HASH),Date.now()+lifetime).run();
   return json({authenticated:true,username:env.ADMIN_USERNAME||'adminx'},200,{'Set-Cookie':cookie(request,value)});
  }
  if(!await authenticated(request,env))throw new HttpError('Entre para acessar o painel.',401);
  if(path==='/api/adminx/session'&&request.method==='GET')return json({authenticated:true,username:env.ADMIN_USERNAME||'adminx'});
  if(path==='/api/adminx/logout'&&request.method==='POST'){await env.DB.prepare('DELETE FROM admin_sessions WHERE token_hash=?').bind(sha(cookieToken(request))).run();return json({ok:true},200,{'Set-Cookie':cookie(request,'',0)});}
  if(path==='/api/adminx/settings'){
   if(request.method==='GET')return json(await publicSettings(env));
   if(request.method==='PUT')return json(await saveSettings(env,await bodyJson(request),validateCredential));
  }
  if(path==='/api/adminx/summary'&&request.method==='GET'){
   const from=range(url),now=Date.now();
   const [totals,campaigns,online,pages]=await Promise.all([
    env.DB.prepare("SELECT COUNT(*) AS orders,COALESCE(SUM(CASE WHEN status='paid' THEN 1 ELSE 0 END),0) AS paid,COALESCE(SUM(CASE WHEN status IN ('creating','review','pending') THEN 1 ELSE 0 END),0) AS pending,COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) AS revenue,COALESCE(SUM(CASE WHEN status IN ('refunded','chargedback') THEN amount ELSE 0 END),0) AS refunded FROM orders WHERE created_at>=?").bind(from).first(),
    env.DB.prepare("SELECT COALESCE(utm_source,'Direto / sem UTM') AS source,COALESCE(utm_campaign,'—') AS campaign,COUNT(*) AS orders,COALESCE(SUM(CASE WHEN status='paid' THEN 1 ELSE 0 END),0) AS paid,COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) AS revenue FROM orders WHERE created_at>=? GROUP BY utm_source,utm_campaign ORDER BY revenue DESC,orders DESC LIMIT 50").bind(from).all(),
    env.DB.prepare('SELECT COUNT(*) AS count FROM online_visitors WHERE seen_at>=?').bind(now-120000).first(),
    env.DB.prepare('SELECT path,COUNT(*) AS count FROM online_visitors WHERE seen_at>=? GROUP BY path ORDER BY count DESC LIMIT 10').bind(now-120000).all()
   ]);
   return json({totals,attribution:campaigns.results,online:Number(online.count),pages:pages.results,onlineWindowSeconds:120,updatedAt:now});
  }
  if(['/api/adminx/funnel','/api/adminx/abandoned'].includes(path)&&request.method==='GET'){
   const page=Number(url.searchParams.get('page')||1);if(!Number.isInteger(page)||page<1||page>100000)throw new HttpError('Página inválida.');
   return json(await visitorReport(env,{abandoned:path.endsWith('/abandoned'),from:range(url),page}));
  }
  if(path==='/api/adminx/orders'&&request.method==='GET'){
   const page=Number(url.searchParams.get('page')||1),status=url.searchParams.get('status')||'',q=(url.searchParams.get('q')||'').trim();
   if(!Number.isInteger(page)||page<1||page>100000||q.length>100||(status&&!statuses.includes(status)))throw new HttpError('Filtro inválido.');
   let clause='created_at>=?',values=[range(url)];
   if(status){clause+=' AND status=?';values.push(status);}
   if(q){clause+=" AND (LOWER(id) LIKE ? ESCAPE '!' OR LOWER(details) LIKE ? ESCAPE '!')";const search='%'+q.toLowerCase().replace(/[!%_]/g,c=>'!'+c)+'%';values.push(search,search);}
   const [count,rows]=await Promise.all([env.DB.prepare('SELECT COUNT(*) AS count FROM orders WHERE '+clause).bind(...values).first(),env.DB.prepare('SELECT * FROM orders WHERE '+clause+' ORDER BY created_at DESC,id DESC LIMIT 25 OFFSET ?').bind(...values,(page-1)*25).all()]);
   return json({orders:rows.results.map(row=>orderView(row)),total:Number(count.count),page,pageSize:25});
  }
  const match=path.match(/^\/api\/adminx\/orders\/(SB-[a-f0-9-]{36})(\/refresh|\/fulfillment)?$/);
  if(match){let row=await env.DB.prepare('SELECT * FROM orders WHERE id=?').bind(match[1]).first();if(!row)throw new HttpError('Pedido não encontrado.',404);
   if(match[2]==='/fulfillment'&&request.method==='POST')return json(await orderDetail(env,await updateFulfillment(env,row,await bodyJson(request,1024))));
   if(match[2]==='/refresh'&&request.method==='POST'){if(!await rateLimit(env.DB,'refresh:'+match[1],6,60000))throw new HttpError('Aguarde antes de consultar novamente.',429);row=await refreshOrder(env,{...row,checked_at:0});return json(await orderDetail(env,row));}
   if(!match[2]&&request.method==='GET')return json(await orderDetail(env,row));
  }
  throw new HttpError('Não encontrado.',404);
 }catch(error){return json({error:error instanceof HttpError?error.message:'Não foi possível carregar o painel agora.'},error instanceof HttpError?error.status:500);}
}
export async function handlePresence(request,env){
 try{
  if(request.method!=='POST')throw new HttpError('Método inválido.',405);sameOrigin(request,env);
  if(!env.SETTINGS_ENCRYPTION_KEY||!env.DB)return json({ok:false},503);
  const body=await bodyJson(request,12000);if(typeof body.path!=='string'||!/^\/[a-zA-Z0-9/_-]*$/.test(body.path)||body.path.length>300||body.path.startsWith('/adminx'))throw new HttpError('Página inválida.');
  let [id,signature]=(request.headers.get('Cookie')?.match(/(?:^|;\s*)sheik_visit=([a-f0-9]{64}\.[a-f0-9]{64})(?:;|$)/)?.[1]||'').split('.'),setCookie;
  if(!id||!equal(signature,sign(env,'visit:'+id))){
   if(!await rateLimit(env.DB,'visits:'+sha(request.headers.get('CF-Connecting-IP')||'local'),120,600000))throw new HttpError('Aguarde.',429);
   id=token();signature=sign(env,'visit:'+id);setCookie=`sheik_visit=${id}.${signature}; Path=/api/presence; HttpOnly; SameSite=Lax; Max-Age=2592000${new URL(request.url).protocol==='https:'?'; Secure':''}`;
  }
  await recordVisit(request,env,sha(id),body);
  return json({ok:true},200,setCookie?{'Set-Cookie':setCookie}:{});
 }catch(error){return json({ok:false},error instanceof HttpError?error.status:500);}
}
export async function cleanAdminTables(env){const now=Date.now();await env.DB.prepare('DELETE FROM online_visitors WHERE seen_at<?').bind(now-30*86400000).run();await env.DB.prepare('DELETE FROM request_limits WHERE window_start<?').bind(now-86400000).run();await env.DB.prepare('DELETE FROM admin_sessions WHERE expires_at<?').bind(now).run();}

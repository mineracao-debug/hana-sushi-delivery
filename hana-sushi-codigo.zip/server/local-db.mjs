import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync,mkdirSync} from 'node:fs';
export function localDB(filename=':memory:'){
 const db=new DatabaseSync(filename);
 db.exec('CREATE TABLE IF NOT EXISTS local_migrations (name TEXT PRIMARY KEY)');
 for(const name of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort()){
  if(db.prepare('SELECT name FROM local_migrations WHERE name=?').get(name))continue;
  db.exec(readFileSync('drizzle/'+name,'utf8'));
  db.prepare('INSERT INTO local_migrations VALUES (?)').run(name);
 }
 return {prepare(sql){let values=[];return {bind(...v){values=v;return this;},async first(){return db.prepare(sql).get(...values)||null;},async all(){return {results:db.prepare(sql).all(...values)};},async run(){const r=db.prepare(sql).run(...values);return {meta:{changes:r.changes},success:true};}};},close(){db.close();}};
}

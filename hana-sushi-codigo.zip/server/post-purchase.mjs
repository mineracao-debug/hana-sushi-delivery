import products from './products.json' with {type:'json'};
import {HttpError} from './security.mjs';
const validId=id=>/^SB-[a-f0-9-]{36}$/.test(id||'');
export async function ownedOrder(env,session,id){
 if(!validId(id))throw new HttpError('Pedido não encontrado.',404);
 const row=await env.DB.prepare('SELECT * FROM orders WHERE id=? AND session_hash=?').bind(id,session).first();
 if(!row)throw new HttpError('Pedido não encontrado.',404);return row;
}
export async function paidParent(env,session,id){
 const parent=await ownedOrder(env,session,id),root=parent.root_order_id?await ownedOrder(env,session,parent.root_order_id):parent;
 if(parent.status!=='paid'||root.status!=='paid')throw new HttpError('O pagamento precisa estar confirmado para adicionar produtos.',409);
 return {parent,root,details:JSON.parse(parent.details)};
}
export async function existingAddition(env,parent){return env.DB.prepare("SELECT * FROM orders WHERE parent_order_id=? AND status<>'failed' LIMIT 1").bind(parent).first();}
export async function postPurchase(env,session,id,publicOrder,refresh){
 const requested=await ownedOrder(env,session,id),root=await ownedOrder(env,session,requested.root_order_id||requested.id);
 // Resume the newest addition on refresh/back/multiple tabs, instead of opening
 // another charge from an old receipt. A chain has only one live child per parent.
 let latest=await env.DB.prepare("SELECT o.* FROM orders o WHERE o.session_hash=? AND (o.id=? OR o.root_order_id=?) AND o.status<>'failed' AND NOT EXISTS (SELECT 1 FROM orders child WHERE child.parent_order_id=o.id AND child.status<>'failed') LIMIT 1").bind(session,root.id,root.id).first()||root;
 try{latest=await refresh(env,latest);}catch{/* Keep the last server-confirmed state. */}
 const confirmedRoot=latest.id===root.id?latest:root;
 const [paid,totals]=await Promise.all([
  env.DB.prepare("SELECT * FROM orders WHERE session_hash=? AND (id=? OR root_order_id=?) AND status='paid' ORDER BY created_at DESC,id DESC LIMIT 100").bind(session,root.id,root.id).all(),
  env.DB.prepare("SELECT COUNT(*) AS count,COALESCE(SUM(amount),0) AS amount FROM orders WHERE session_hash=? AND (id=? OR root_order_id=?) AND status='paid'").bind(session,root.id,root.id).first()
 ]);
 const bought=new Set(paid.results.flatMap(r=>JSON.parse(r.details).items.map(i=>i.externalRef)));
 const available=products.filter(p=>p.max>0),fresh=available.filter(p=>!bought.has(p.id));
 const offers=(fresh.length?fresh:available).sort((a,b)=>a.price-b.price||a.id.localeCompare(b.id)).slice(0,6).map(p=>({id:p.id,title:p.title,price:p.price,options:[...new Set((p.options||[]).flatMap(o=>o.values||[]))]}));
 return {payment:publicOrder(latest),rootOrderId:root.id,rootPaid:confirmedRoot.status==='paid',canAdd:latest.status==='paid'&&confirmedRoot.status==='paid',offers:latest.status==='paid'&&confirmedRoot.status==='paid'?offers:[],shipping:0,paidTotal:Number(totals.amount),paidCount:Number(totals.count),receipts:paid.results.map(publicOrder)};
}

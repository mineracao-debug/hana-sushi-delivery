import test from 'node:test';
import assert from 'node:assert/strict';
import {handleApi,validateOrder,pixCode} from './payments.mjs';
import {localDB} from './local-db.mjs';
import {gatewayPayload} from './gateways.mjs';
const ORIGIN='http://127.0.0.1:4173';
const payload=()=>({lines:[{id:'1',qty:1}],customer:{name:'Cliente Teste',email:'cliente@example.com',cpf:'52998224725',phone:'11999999999'},ship:'retirada'});
function sampleCode(){let s='00020126360014br.gov.bcb.pix0114TESTESEMVALOR005204000053039865802BR5905TESTE6009SAO PAULO6304',crc=0xffff;for(const b of new TextEncoder().encode(s)){crc^=b<<8;for(let i=0;i<8;i++)crc=(crc&0x8000)?((crc<<1)^0x1021)&0xffff:(crc<<1)&0xffff;}return s+crc.toString(16).padStart(4,'0').toUpperCase();}
function fixture(fetcher){const DB=localDB();return {DB,UMBRELLAPAG_API_KEY:'test-secret-only',__fetch:fetcher};}
const request=(path,options={})=>new Request(ORIGIN+path,options);
async function session(env){const r=await handleApi(request('/api/checkout-config'),env);return r.headers.get('Set-Cookie').split(';')[0];}
function create(env,cookie,key='test-request-00000001',body=payload()){return handleApi(request('/api/pix',{method:'POST',headers:{Origin:ORIGIN,'Content-Type':'application/json',Cookie:cookie,'Idempotency-Key':key},body:JSON.stringify(body)}),env);}
const response=data=>new Response(JSON.stringify({status:200,data,error:null}),{status:200});
test('server derives item amounts and freight; ignores browser supplied prices',()=>{
 const p=payload();p.amount=1;p.lines[0].price=1;
 assert.equal(validateOrder(p).amount,2990);
 p.ship='entrega';p.address={cep:'01001000',street:'Praça da Sé',number:'1',district:'Sé',city:'São Paulo',uf:'SP'};
 assert.equal(validateOrder(p).amount,2990);p.lines[0].qty=3;assert.equal(validateOrder(p).amount,8970);
});
test('reject invalid CPF, quantities, product IDs and variants',()=>{
 for(const change of [p=>p.customer.cpf='00000000000',p=>p.lines[0].qty=-1,p=>p.lines[0].qty=1.5,p=>p.lines[0].id='unknown',p=>p.lines[0].opt='invalid']){const p=payload();change(p);assert.throws(()=>validateOrder(p));}
});
test('normalizes phone before gateway payload and rejects incomplete numbers',()=>{
 const body=payload();body.ship='entrega';body.address={cep:'01001000',street:'Praça da Sé',number:'1',district:'Sé',city:'São Paulo',uf:'SP'};
 for(const phone of ['11999999999','(11) 99999-9999','+55 (11) 99999-9999']){
  body.customer.phone=phone;const order=validateOrder(body);
  assert.equal(order.customer.phone,'11999999999');
  assert.equal(gatewayPayload('sharkpay',order,'test-phone',{}).payer.phone,'+5511999999999');
  assert.equal(gatewayPayload('umbrellapag',order,'test-phone',{}).customer.phone,'11999999999');
 }
 body.customer.phone='99999-9999';assert.throws(()=>validateOrder(body),/DDD/);
});
test('QR extraction requires a real EMV structure and matching CRC',()=>{
 assert.equal(pixCode({qrCode:'https://example.com/qr.png'}),null);
 assert.equal(pixCode({qrCode:sampleCode().slice(0,-1)+'Z'}),null);
 assert.equal(pixCode({pix:{qrcode:sampleCode()}}),sampleCode());
});
test('creation sends documented authentication and duplicates reuse one charge',async()=>{
 let calls=0;const env=fixture(async(url,options)=>{calls++;assert.equal(url,'https://api-gateway.umbrellapag.com/api/user/transactions');assert.equal(options.headers['x-api-key'],'test-secret-only');assert.equal(options.headers['User-Agent'],'UMBRELLAB2B/1.0');const body=JSON.parse(options.body);assert.equal(body.amount,2990);assert.equal(body.paymentMethod,'PIX');assert.equal(body.card,undefined);return response({id:'provider-1',amount:2990,currency:'BRL',paymentMethod:'PIX',status:'WAITING_PAYMENT',qrCode:sampleCode()});});
 const cookie=await session(env),first=await create(env,cookie);assert.equal(first.status,201);const order=await first.json();assert.equal(order.paid,false);assert.equal(order.qrcode,sampleCode());assert.ok(!JSON.stringify(order).includes('test-secret-only'));assert.ok(!JSON.stringify(order).includes('52998224725'));
 const duplicate=await create(env,cookie);assert.equal((await duplicate.json()).id,order.id);assert.equal(calls,1);
 const foreign=await handleApi(request('/api/pix-status?id='+order.id),env);assert.equal(foreign.status,404);env.DB.close();
});
test('ambiguous timeout is recorded and never automatically creates a duplicate',async()=>{
 let calls=0;const env=fixture(async()=>{calls++;throw new Error('network timeout');}),cookie=await session(env);
 const first=await create(env,cookie);assert.equal(first.status,202);assert.equal((await first.json()).status,'review');
 await create(env,cookie);assert.equal(calls,1);env.DB.close();
});

test('Sharkpay accepts optional metadata omission and returns one usable Pix per checkout request',async()=>{
 let calls=0,externalRef;
 const env=fixture(async(url,options)=>{
  calls++;assert.equal(url,'https://api.gatewaypayshark.com.br/v1/payment');
  const sent=JSON.parse(options.body);externalRef=sent.externalRef;
  // Regression fixture for the real schema.validation.default response:
  // metadata is optional, but supplying it requires the seller's full identity.
  if(sent.metadata&&['provider','orderId','sellerTaxId','sellerEmail'].some(key=>!sent.metadata[key]))return Response.json({code:'schema.validation.default',message:'Request contains invalid values.'},{status:400});
  assert.equal(sent.amount,2990);assert.equal(sent.delivery.address.zipCode,'01001000');assert.equal(sent.payer.phone,'+5511999999999');
  return Response.json({id:'shark-accepted',amount:sent.amount,currency:'BRL',method:'PIX',status:'PENDING',data:{copypaste:sampleCode()}});
 });
 env.SHARKPAY_API_KEY='shark-test-key';
 await env.DB.prepare('INSERT INTO shop_settings (id,value,version) VALUES (1,?,1)').bind(JSON.stringify({active:'sharkpay',credentials:{},sharkFee:{bps:390,fixed:250},pickupAddress:null})).run();
 const cookie=await session(env),body=payload();body.customer.phone='+55 (11) 99999-9999';body.ship='entrega';body.address={cep:'01001000',street:'Praça da Sé',number:'1',district:'Sé',city:'São Paulo',uf:'SP'};
 const first=await create(env,cookie,'shark-metadata-regression',body);assert.equal(first.status,201);
 const order=await first.json();assert.equal(order.qrcode,sampleCode());assert.equal(order.status,'pending');assert.equal(order.id,externalRef);
 const duplicate=await create(env,cookie,'shark-metadata-regression',body);assert.equal((await duplicate.json()).id,order.id);assert.equal(calls,1);
 env.DB.close();
});
test('status is confirmed through the gateway, with matching amount and ownership',async()=>{
 let phase=0;const env=fixture(async()=>response({id:'provider-2',amount:phase===2?100:2990,currency:'BRL',paymentMethod:'PIX',status:phase?'PAID':'WAITING_PAYMENT',qrCode:sampleCode()}));
 const cookie=await session(env),created=await (await create(env,cookie)).json();
 phase=2;await env.DB.prepare('UPDATE orders SET checked_at=0 WHERE id=?').bind(created.id).run();
 let result=await handleApi(request('/api/pix-status?id='+created.id,{headers:{Cookie:cookie}}),env);assert.equal((await result.json()).paid,false);
 phase=1;result=await handleApi(request('/api/pix-status?id='+created.id,{headers:{Cookie:cookie}}),env);assert.equal((await result.json()).paid,true);env.DB.close();
});
test('cross-origin creation and callback without shared secret are rejected',async()=>{
 const env=fixture(()=>{throw new Error('Must never call gateway');});
 const r=await handleApi(request('/api/pix',{method:'POST',headers:{Origin:'https://example.com','Content-Type':'application/json'},body:'{}'}),env);assert.equal(r.status,403);
 const hook=await handleApi(request('/api/umbrellapag/webhook',{method:'POST',body:'{"data":{"status":"paid"}}'}),env);assert.equal(hook.status,401);env.DB.close();
});
test('configured storefront origin can create through the shared backend',async()=>{
 const env=fixture(async()=>response({id:'netlify-test',amount:2990,currency:'BRL',paymentMethod:'PIX',status:'WAITING_PAYMENT',qrCode:sampleCode()}));
 env.PUBLIC_STORE_ORIGINS='https://store.netlify.app';
 const cookie=await session(env);
 const result=await handleApi(request('/api/pix',{method:'POST',headers:{Origin:'https://store.netlify.app','Content-Type':'application/json',Cookie:cookie,'Idempotency-Key':'netlify-origin-test-1'},body:JSON.stringify(payload())}),env);
 assert.equal(result.status,201);assert.equal((await result.json()).paid,false);env.DB.close();
});

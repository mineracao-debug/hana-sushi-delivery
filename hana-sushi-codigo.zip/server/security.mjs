import {randomBytes,scrypt,timingSafeEqual,createHash,createCipheriv,createDecipheriv,createHmac} from 'node:crypto';
import {promisify} from 'node:util';
const derive=promisify(scrypt);
export const sha=value=>createHash('sha256').update(value).digest('hex');
export const token=()=>randomBytes(32).toString('hex');
export const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&timingSafeEqual(Buffer.from(sha(a)),Buffer.from(sha(b)));
export async function passwordHash(password){const salt=randomBytes(16).toString('hex');return `scrypt:${salt}:${(await derive(password,salt,64)).toString('hex')}`;}
export async function passwordMatches(password,encoded){
 const parts=String(encoded||'').split(':');
 if(parts.length!==3||parts[0]!=='scrypt'||!/^[a-f0-9]{32}$/.test(parts[1])||!/^[a-f0-9]{128}$/.test(parts[2]))return false;
 return equal((await derive(password,parts[1],64)).toString('hex'),parts[2]);
}
function key(env){if(!/^[a-f0-9]{64}$/i.test(env.SETTINGS_ENCRYPTION_KEY||''))throw new Error('SETTINGS_KEY_UNAVAILABLE');return Buffer.from(env.SETTINGS_ENCRYPTION_KEY,'hex');}
export function seal(env,value,context){const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key(env),iv);cipher.setAAD(Buffer.from(context));const encrypted=Buffer.concat([cipher.update(value,'utf8'),cipher.final()]);return [iv,cipher.getAuthTag(),encrypted].map(b=>b.toString('base64url')).join('.');}
export function unseal(env,value,context){const [iv,tag,data]=value.split('.').map(v=>Buffer.from(v,'base64url')),cipher=createDecipheriv('aes-256-gcm',key(env),iv);cipher.setAAD(Buffer.from(context));cipher.setAuthTag(tag);return Buffer.concat([cipher.update(data),cipher.final()]).toString('utf8');}
export function sign(env,value){return createHmac('sha256',key(env)).update(value).digest('hex');}
export async function rateLimit(DB,id,limit,windowMs){
 const start=Math.floor(Date.now()/windowMs)*windowMs;
 await DB.prepare('INSERT INTO request_limits (id,window_start,hits) VALUES (?,?,1) ON CONFLICT(id) DO UPDATE SET hits=CASE WHEN request_limits.window_start=? THEN request_limits.hits+1 ELSE 1 END,window_start=?').bind(id,start,start,start).run();
 const row=await DB.prepare('SELECT hits FROM request_limits WHERE id=?').bind(id).first();return Number(row.hits)<=limit;
}
export class HttpError extends Error{constructor(message,status=400){super(message);this.status=status;}}
export const json=(body,status=200,headers={})=>Response.json(body,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',...headers}});
export function sameOrigin(request,env={}){
 const origin=request.headers.get('Origin');
 const allowed=new Set([new URL(request.url).origin]);
 for(const value of String(env.PUBLIC_STORE_ORIGINS||'').split(',')){
  try{const url=new URL(value.trim());if(url.protocol==='https:'&&url.origin===value.trim())allowed.add(url.origin);}catch{}
 }
 if(!origin||!allowed.has(origin))throw new HttpError('Origem inválida.',403);
}
export async function bodyJson(request,max=16000){if(!request.headers.get('Content-Type')?.startsWith('application/json'))throw new HttpError('Formato inválido.',415);const reader=request.body?.getReader();let chunks=[],size=0;if(reader){while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max){await reader.cancel();throw new HttpError('Dados muito grandes.',413);}chunks.push(Buffer.from(value));}}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw new HttpError('Dados inválidos.');}}

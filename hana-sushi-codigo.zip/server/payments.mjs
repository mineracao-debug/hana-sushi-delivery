import products from './products.json' with { type: 'json' };
import {cleanTracking,notifyUtmify} from './utmify.mjs';
import {activeGateway} from './gateway-settings.mjs';
import {createPayment,findPayment,gatewayPayload} from './gateways.mjs';
import {HttpError as PaymentError,equal,bodyJson,sameOrigin} from './security.mjs';
import {paidParent,existingAddition,postPurchase} from './post-purchase.mjs';

const productMap=new Map(products.map(p=>[p.id,p]));
const json=(body,status=200,headers={})=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
const digits=s=>String(s||'').replace(/\D/g,'');
const hash=async s=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))),b=>b.toString(16).padStart(2,'0')).join('');
const random=()=>crypto.randomUUID();
const fail=(message,status=400)=>{throw new PaymentError(message,status);};
const text=(v,min=1,max=150)=>typeof v==='string'&&v.trim().length>=min&&v.trim().length<=max?v.trim():fail('Preencha os dados do pedido corretamente.');
export function validCPF(input){const c=digits(input);if(c.length!==11||/^(\d)\1+$/.test(c))return false;for(let t=9;t<11;t++){let sum=0;for(let i=0;i<t;i++)sum+=+c[i]*(t+1-i);if((sum*10)%11%10!==+c[t])return false;}return true;}

// Prices, allowed options and freight are resolved exclusively from the server catalog.
export function validateOrder(body){
 if(!body||!Array.isArray(body.lines)||!body.lines.length||body.lines.length>30)fail('Revise os produtos do carrinho.');
 const merged=new Map();
 for(const line of body.lines){
  const p=productMap.get(String(line.id));
  if(!p||line.plan||!Number.isInteger(line.qty)||line.qty<1||line.qty>p.max)fail('Há um produto ou quantidade inválida no carrinho.');
  const opt=String(line.opt||'');
  const choices=(p.options||[]).flatMap(o=>o.values||[]);
  if(opt&&(!choices.length||!choices.includes(opt)))fail('Escolha uma opção válida para o produto.');
  const key=p.id+'|'+opt,old=merged.get(key);
  const quantity=(old?.quantity||0)+line.qty;
  if(quantity>p.max)fail('A quantidade excede o limite do produto.');
  merged.set(key,{title:p.title+(opt?' — '+opt:''),unitPrice:p.price,quantity,tangible:true,externalRef:p.id});
 }
 const mainCount=body.lines.filter(l=>!productMap.get(String(l.id)).extra&&!productMap.get(String(l.id)).gift).reduce((s,l)=>s+l.qty,0);
 if(!mainCount)fail('Escolha um combo para continuar.');
 if(body.lines.filter(l=>productMap.get(String(l.id)).gift).reduce((s,l)=>s+l.qty,0)>1)fail('Escolha apenas uma sobremesa gratuita por pedido.');
 if(body.lines.filter(l=>productMap.get(String(l.id)).extra).reduce((s,l)=>s+l.qty,0)>mainCount*5)fail('Escolha até cinco complementos por combo.');
 const customer=body.customer||{},name=text(customer.name,3,100),email=text(customer.email,5,160).toLowerCase();
 if(!name.includes(' ')||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))fail('Informe nome completo e e-mail válido.');
 const cpf=digits(customer.cpf),phone=digits(customer.phone);
 if(!validCPF(cpf))fail('CPF inválido.');
 if(!/^\d{10,11}$/.test(phone))fail('Informe um celular com DDD.');
 if(!['entrega','retirada'].includes(body.ship))fail('Escolha a forma de entrega.');
 let address;
 if(body.ship==='entrega'){
  const a=body.address||{},zipCode=digits(a.cep),state=String(a.uf||'').toUpperCase();
  if(zipCode.length!==8||!['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'].includes(state))fail('Informe CEP e UF válidos.');
  address={street:text(a.street,2),streetNumber:text(a.number,1,20),complement:String(a.comp||'').slice(0,100),zipCode,neighborhood:text(a.district,2),city:text(a.city,2),state,country:'BR'};
 }
 const items=[...merged.values()],subtotal=items.reduce((sum,p)=>sum+p.unitPrice*p.quantity,0);
 const shipping=0,amount=subtotal;
 if(!Number.isSafeInteger(amount)||amount<1||amount>5000000)fail('Valor do pedido fora do limite.');
 return {customer:{name,email,document:{type:'CPF',number:cpf},phone,...(address?{address}:{})},items,amount,subtotal,shipping,ship:body.ship,address,tracking:cleanTracking(body.tracking)};
}

// The vendor's examples leave PIX fields null. Accept only an actual EMV code,
// with its CRC checked; never treat a URL, image or arbitrary string as a payable PIX.
export function pixCode(data){
 const candidates=[data?.qrCode,data?.pix, data?.pix?.qrcode,data?.pix?.qrCode,data?.pix?.qrCodeText,data?.pix?.copyPaste,data?.pix?.payload];
 for(const candidate of candidates){
  if(typeof candidate!=='string')continue;
  const code=candidate.trim();
  if(!/^000201/.test(code)||!/br\.gov\.bcb\.pix/i.test(code)||!/^.{20,4096}6304[0-9A-Fa-f]{4}$/.test(code))continue;
  let crc=0xffff;for(const b of new TextEncoder().encode(code.slice(0,-4))){crc^=b<<8;for(let j=0;j<8;j++)crc=(crc&0x8000)?((crc<<1)^0x1021)&0xffff:(crc<<1)&0xffff;}
  if(crc.toString(16).padStart(4,'0').toUpperCase()===code.slice(-4).toUpperCase())return code;
 }
 return null;
}
export function normalizedStatus(data,amount){
 if(!data||Number(data.amount)!==amount||(data.currency&&data.currency!=='BRL')||data.paymentMethod!=='PIX')fail('Não foi possível confirmar os dados da cobrança.',502);
 const state=String(data.status||'').toUpperCase();
 return state==='PAID'?'paid':['REFUSED','CANCELED','REFUNDED','CHARGEDBACK'].includes(state)?state.toLowerCase():'pending';
}
const publicOrder=row=>{const details=typeof row.details==='string'?JSON.parse(row.details):row.details;return {id:row.id,ref:row.id,amount:row.amount,qrcode:row.pix_code||null,expirationDate:row.expires_at||null,status:row.status,paid:row.status==='paid',approvedAt:row.approved_at?Number(row.approved_at):null,parentOrderId:row.parent_order_id||null,rootOrderId:row.root_order_id||row.id,order:details?{id:row.id,total:row.amount,subtotal:details.subtotal,shipping:details.shipping,ship:details.ship,customer:{name:details.customer.name.split(' ')[0]},items:details.items.map(i=>({id:i.externalRef,title:i.title,qty:i.quantity,price:i.unitPrice,opt:i.option||''}))}:null};};
function confirmedFields(data,row){
 const proposed=normalizedStatus(data,row.amount);
 const rank={creating:0,review:0,pending:0,failed:1,refused:1,canceled:1,paid:2,refunded:3,chargedback:4};
 const status=(rank[proposed]??0)<(rank[row.status]??0)?row.status:proposed;
 const now=Date.now(),net=data.fee?.netAmount;
 const validDate=value=>typeof value==='string'&&Number.isFinite(Date.parse(value))?Date.parse(value):null;
 return {status,fee:Number.isSafeInteger(net)&&net>=0&&net<=row.amount?row.amount-net:row.fee_cents??null,
  approved:row.approved_at||validDate(data.paidAt)||(status==='paid'?now:null),
  refunded:row.refunded_at||validDate(data.refundedAt)||(['refunded','chargedback'].includes(status)?now:null)};
}
export async function refreshOrder(env,row){
 if(!row.provider_id||Date.now()-row.checked_at<10000)return row;
 const data=await findPayment(env,row);
 if(String(data.id)!==row.provider_id)fail('Não foi possível confirmar a cobrança.',502);
 const confirmed=confirmedFields(data,row),code=pixCode(data)||row.pix_code;
 const now=Math.max(Date.now(),Number(row.updated_at)+1);
 // A slow callback cannot overwrite a newer confirmed state or move it backwards.
 await env.DB.prepare('UPDATE orders SET status=?,provider_status=?,pix_code=?,checked_at=?,updated_at=?,approved_at=?,refunded_at=?,fee_cents=?,utmify_next_attempt=? WHERE id=? AND updated_at=? AND status=?').bind(confirmed.status,String(data.status||''),code,now,now,confirmed.approved,confirmed.refunded,confirmed.fee,confirmed.status!==row.status||confirmed.fee!==row.fee_cents?0:row.utmify_next_attempt,row.id,row.updated_at,row.status).run();
 const updated=await env.DB.prepare('SELECT * FROM orders WHERE id=?').bind(row.id).first();
 if(updated.utmify_sent_status!==updated.status)await notifyUtmify(env,row.id);
 return updated;
}

export async function handleApi(request,env){
 const url=new URL(request.url);let setCookie;
 try{
  const cookie=request.headers.get('Cookie')?.match(/(?:^|;\s*)sheik_checkout=([a-f0-9-]{72})/)?.[1];
  const session=cookie||random()+random();
  const sessionHash=await hash(session);
  if(!cookie)setCookie=`sheik_checkout=${session}; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800${url.protocol==='https:'?'; Secure':''}`;
  const headers=setCookie?{'Set-Cookie':setCookie}:{};
  if(request.method==='GET'&&url.pathname==='/api/checkout-config'){const gateway=env.DB?await activeGateway(env):null;return json({utmifyPixelId:env.UTMIFY_PIXEL_ID||null,pixEnabled:!!gateway?.key,pickupEnabled:gateway?.provider!=='sharkpay'||!!gateway?.settings.pickupAddress},200,headers);}
  if(!env.DB)fail('O pagamento Pix ainda não está configurado. Seu carrinho foi mantido.',503);
  if(request.method==='POST'&&url.pathname==='/api/pix'){
   sameOrigin(request,env);
   if(!request.headers.get('Content-Type')?.startsWith('application/json'))fail('Formato inválido.',415);
   const body=await bodyJson(request,24000);
   const key=request.headers.get('Idempotency-Key');if(!/^[a-zA-Z0-9-]{16,80}$/.test(key||''))fail('Reabra o checkout para continuar.');
   let order;
   if(body.parentOrderId!==undefined){
    const {parent,root,details}=await paidParent(env,sessionHash,body.parentOrderId),c=details.customer,a=details.address;
    order=validateOrder({lines:body.lines,customer:{name:c.name,email:c.email,cpf:c.document.number,phone:c.phone},ship:details.ship,address:a?{cep:a.zipCode,street:a.street,number:a.streetNumber,comp:a.complement,district:a.neighborhood,city:a.city,uf:a.state}:undefined,tracking:details.tracking});
    for(const line of body.lines){const choices=(productMap.get(String(line.id)).options||[]).flatMap(o=>o.values||[]);if(choices.length&&!line.opt)fail('Escolha a opção do produto.');}
    order.items=order.items.map(item=>({...item,option:body.lines.find(l=>String(l.id)===item.externalRef&&item.title.endsWith(l.opt?' — '+l.opt:productMap.get(String(l.id)).title))?.opt||''}));
    order.shipping=0;order.amount=order.subtotal;order.parentOrderId=parent.id;order.rootOrderId=root.id;
   }else order=validateOrder(body);
   const requestHash=await hash(JSON.stringify(order));
   let existing=await env.DB.prepare('SELECT * FROM orders WHERE session_hash=? AND request_key=?').bind(sessionHash,key).first();
   if(existing){
    if(existing.request_hash!==requestHash)fail('O pedido mudou. Revise os dados antes de gerar outro Pix.',409);
    if(existing.status==='creating'||existing.status==='review')return json({...publicOrder(existing),error:'A cobrança está sendo confirmada. Aguarde para evitar duplicidade.'},202,headers);
    if(existing.utmify_sent_status!==existing.status)await notifyUtmify(env,existing.id);
    return json(publicOrder(existing),200,headers);
   }
   if(order.parentOrderId){const addition=await existingAddition(env,order.parentOrderId);if(addition)return json({...publicOrder(addition),resumed:true},200,headers);}
   const recent=await env.DB.prepare("SELECT COUNT(*) AS count FROM orders WHERE session_hash=? AND created_at>? AND status<>'paid'").bind(sessionHash,Date.now()-600000).first();
   if(recent.count>=5)fail('Aguarde alguns minutos antes de criar outro pedido.',429);
   const gateway=await activeGateway(env);if(!gateway.key)fail('O pagamento está temporariamente indisponível.',503);
   const id='SB-'+random(),now=Date.now();
   if(gateway.provider==='sharkpay'){order.gatewayFee=gateway.settings.sharkFee;order.pickupAddress=gateway.settings.pickupAddress;}
   gatewayPayload(gateway.provider,order,id,env);
   const clientIp=request.headers.get('CF-Connecting-IP');
   if(clientIp&&/^[a-fA-F0-9:.]{3,45}$/.test(clientIp))order.clientIp=clientIp;
   const insert=await env.DB.prepare('INSERT OR IGNORE INTO orders (id,session_hash,request_key,request_hash,status,amount,details,created_at,updated_at,checked_at,provider,credential_id,utm_source,utm_campaign,parent_order_id,root_order_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id,sessionHash,key,requestHash,'creating',order.amount,JSON.stringify(order),now,now,0,gateway.provider,gateway.credentialId,order.tracking.utm_source,order.tracking.utm_campaign,order.parentOrderId||null,order.rootOrderId||null).run();
   if(insert.meta.changes!==1){if(order.parentOrderId){const addition=await existingAddition(env,order.parentOrderId);if(addition)return json({...publicOrder(addition),resumed:true},200,headers);}fail('O pedido já está sendo processado. Aguarde.',409);}
   try{
    const data=await createPayment(env,gateway,order,id);
    if(!data.id)throw new PaymentError('A cobrança precisa de conferência.',502);
    // Save the known provider ID before parsing the payment: malformed responses
    // must never trigger a second charge on a retry.
    await env.DB.prepare('UPDATE orders SET provider_id=?,updated_at=? WHERE id=?').bind(String(data.id),Date.now(),id).run();
    const confirmed=confirmedFields(data,{amount:order.amount,status:'creating'}),status=confirmed.status,code=pixCode(data);
    const expiry=typeof data.pix?.expirationDate==='string'?data.pix.expirationDate:null;
    await env.DB.prepare('UPDATE orders SET status=?,provider_status=?,pix_code=?,expires_at=?,checked_at=?,updated_at=?,approved_at=?,refunded_at=?,fee_cents=? WHERE id=? AND status=?').bind(status,String(data.status||''),code,expiry,Date.now(),Date.now(),confirmed.approved,confirmed.refunded,confirmed.fee,id,'creating').run();
    await notifyUtmify(env,id);
    return json({...publicOrder({id,amount:order.amount,pix_code:code,expires_at:expiry,status,details:order,approved_at:confirmed.approved,parent_order_id:order.parentOrderId,root_order_id:order.rootOrderId}),...(!code&&status!=='paid'?{error:'Cobrança criada. Aguardando o código Pix do serviço de pagamento.'}:{})},code||status==='paid'?201:202,headers);
   }catch(error){
    await env.DB.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').bind(error.definitive?'failed':'review',Date.now(),id).run();
    return json({id,ref:id,status:error.definitive?'failed':'review',error:error.definitive?error.message:'A cobrança precisa de confirmação. Seu pedido foi preservado; não gere outro Pix.'},error.definitive?422:202,headers);
   }
  }
  if(request.method==='GET'&&url.pathname==='/api/post-purchase')return json(await postPurchase(env,sessionHash,url.searchParams.get('id'),publicOrder,refreshOrder),200,headers);
  if(request.method==='GET'&&url.pathname==='/api/pix-status'){
   const id=url.searchParams.get('id');
   if(!/^SB-[a-f0-9-]{36}$/.test(id||''))fail('Pedido não encontrado.',404);
   let row=await env.DB.prepare('SELECT * FROM orders WHERE id=? AND session_hash=?').bind(id,sessionHash).first();
   if(!row)fail('Pedido não encontrado.',404);
   try{row=await refreshOrder(env,row);}catch{return json({...publicOrder(row),checking:true},200,headers);}
   return json(publicOrder(row),200,headers);
  }
  // Optional webhook: statuses are never trusted from the callback body.
  // The public callback URL is protected by its secret and a gateway status lookup.
  if(request.method==='POST'&&['/api/umbrellapag/webhook','/api/sharkpay/webhook'].includes(url.pathname)){
   const provider=url.pathname.includes('/sharkpay/')?'sharkpay':'umbrellapag';
   const secret=provider==='sharkpay'?env.SHARKPAY_WEBHOOK_SECRET:env.UMBRELLAPAG_WEBHOOK_SECRET;
   if(!secret||!equal(url.searchParams.get('token'),secret))fail('Não autorizado.',401);
   const raw=await request.text();if(raw.length>24000)fail('Payload muito grande.',413);
   let body;try{body=JSON.parse(raw);}catch{fail('Payload inválido.');}
   const providerId=String((provider==='sharkpay'?body.id:body.objectId)||'');if(providerId.length>100)fail('ID inválido.');
   const row=await env.DB.prepare('SELECT * FROM orders WHERE provider=? AND provider_id=?').bind(provider,providerId).first();
   if(row)await refreshOrder(env,{...row,checked_at:0});
   return json({received:true});
  }
  return json({error:'Não encontrado.'},404);
 }catch(error){return json({error:error instanceof PaymentError?error.message:'Não foi possível processar o pedido agora.'},error instanceof PaymentError?error.status:500,setCookie?{'Set-Cookie':setCookie}:{});}
}


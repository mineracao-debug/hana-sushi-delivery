import test from 'node:test';
import assert from 'node:assert/strict';
import {localDB} from './local-db.mjs';
import {handleApi} from './payments.mjs';
import {handleAdmin} from './admin.mjs';
import {passwordHash,token} from './security.mjs';
import {orderProgress} from '../app/order-progress.mjs';
const origin='http://127.0.0.1:4173';
const request=(path,method='GET',body,cookie)=>new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},...(body?{body:JSON.stringify(body)}:{})});
test('real payment confirmation unlocks preparation; only an authenticated admin can advance delivery',async()=>{
 let phase='WAITING_PAYMENT';
 const env={DB:localDB(),ADMIN_USERNAME:'adminx',ADMIN_PASSWORD_HASH:await passwordHash('local-test-password'),SETTINGS_ENCRYPTION_KEY:token(),UMBRELLAPAG_API_KEY:'test-only',__fetch:async()=>Response.json({data:{id:'test-provider',amount:2990,currency:'BRL',paymentMethod:'PIX',status:phase}})};
 try{
  const config=await handleApi(request('/api/checkout-config'),env),customerCookie=config.headers.get('Set-Cookie').split(';')[0];
  const creation=request('/api/pix','POST',{lines:[{id:'1',qty:1}],customer:{name:'Cliente Teste',email:'test@example.com',cpf:'52998224725',phone:'11999999999'},ship:'retirada'},customerCookie);
  creation.headers.set('Idempotency-Key','delivery-test-000001');
  const createdResponse=await handleApi(creation,env);assert.equal(createdResponse.status,202);
  const created=await createdResponse.json(),path='/api/adminx/orders/'+created.id+'/fulfillment';
  const latest=await (await handleApi(request('/api/latest-order','GET',null,customerCookie),env)).json();assert.equal(latest.order.id,created.id);
  const foreignLatest=await (await handleApi(request('/api/latest-order'),env)).json();assert.equal(foreignLatest.order,null);
  assert.equal(created.fulfillment.status,null);assert.equal(orderProgress(created).id,'awaiting_payment');
  const login=await handleAdmin(request('/api/adminx/login','POST',{username:'adminx',password:'local-test-password'}),env),adminCookie=login.headers.get('Set-Cookie').split(';')[0];
  assert.equal((await handleAdmin(request(path,'POST',{status:'out_for_delivery',version:0}),env)).status,401);
  assert.equal((await handleAdmin(request(path,'POST',{status:'out_for_delivery',version:0},customerCookie),env)).status,401);
  assert.equal((await handleAdmin(request(path,'POST',{status:'out_for_delivery',version:0},adminCookie),env)).status,409);
  phase='PAID';await env.DB.prepare('UPDATE orders SET checked_at=0 WHERE id=?').bind(created.id).run();
  const statusPath='/api/pix-status?id='+created.id;
  const paid=await (await handleApi(request(statusPath,'GET',null,customerCookie),env)).json();
  assert.equal(paid.paid,true);assert.equal(paid.fulfillment.status,'preparing');assert.ok(paid.fulfillment.preparingAt);assert.equal(orderProgress(paid).id,'preparing');
  const foreign=request(path,'POST',{status:'out_for_delivery',version:0},adminCookie);foreign.headers.set('Origin','https://foreign.example');assert.equal((await handleAdmin(foreign,env)).status,403);
  assert.equal((await handleAdmin(request(path,'POST',{status:'delivered',version:0},adminCookie),env)).status,409);
  assert.equal((await handleAdmin(request(path,'POST',{status:'unknown',version:0},adminCookie),env)).status,400);
  const dispatchedResponse=await handleAdmin(request(path,'POST',{status:'out_for_delivery',version:0},adminCookie),env);assert.equal(dispatchedResponse.status,200);
  const dispatched=await dispatchedResponse.json();assert.equal(dispatched.fulfillment.status,'out_for_delivery');assert.ok(dispatched.fulfillment.dispatchedAt);assert.equal(dispatched.status,'paid');
  const publicDispatched=await (await handleApi(request(statusPath,'GET',null,customerCookie),env)).json();assert.equal(orderProgress(publicDispatched).id,'out_for_delivery');
  assert.equal((await handleApi(request(statusPath),env)).status,404);
  assert.equal((await handleAdmin(request(path,'POST',{status:'delivered',version:0},adminCookie),env)).status,409);
  const delivered=await (await handleAdmin(request(path,'POST',{status:'delivered',version:1},adminCookie),env)).json();assert.equal(delivered.fulfillment.status,'delivered');assert.ok(delivered.fulfillment.deliveredAt>=delivered.fulfillment.dispatchedAt);
  const refreshed=await (await handleApi(request(statusPath,'GET',null,customerCookie),env)).json();assert.equal(orderProgress(refreshed).id,'delivered');
  assert.equal((await handleAdmin(request(path,'POST',{status:'preparing',version:2},adminCookie),env)).status,409);
  const financial=await env.DB.prepare('SELECT amount,status,provider_id FROM orders WHERE id=?').bind(created.id).first();assert.equal(financial.amount,2990);assert.equal(financial.status,'paid');assert.equal(financial.provider_id,'test-provider');
  phase='REFUNDED';await env.DB.prepare('UPDATE orders SET checked_at=0 WHERE id=?').bind(created.id).run();
  const refunded=await (await handleApi(request(statusPath,'GET',null,customerCookie),env)).json();assert.equal(refunded.fulfillment.status,null);assert.equal(orderProgress(refunded).index,-1);
 }finally{env.DB.close();}
});
test('payment failures never display preparation or delivery progress',()=>{
 for(const status of ['failed','refused','canceled','refunded','chargedback'])assert.equal(orderProgress({status,paid:false,fulfillment:{status:'delivered'}}).index,-1);
 assert.equal(orderProgress({status:'pending',expirationDate:'2000-01-01T00:00:00Z'}).index,-1);
});

import products from './products.json' with {type:'json'};
import {HttpError,sha} from './security.mjs';
import {cleanTracking} from './utmify.mjs';

const catalog=new Map(products.map(p=>[p.id,p]));
export const stages=['browsing','product','cart','details','delivery','payment','pix','paid'];
export const abandonedAfter=30*60000;
// Order ownership comes only from the server-issued checkout cookie. Never accept
// a customer, price or paid status reported by the visitor. An order hint is
// accepted only after verifying its ownership against the checkout cookie.
const joined=`FROM online_visitors v LEFT JOIN orders o ON o.id=(SELECT id FROM orders WHERE session_hash=v.session_hash AND created_at>=v.cart_started_at AND v.cart_started_at>0 ORDER BY created_at DESC,id DESC LIMIT 1)`;
const fields='v.*,o.id AS order_id,o.status AS order_status,o.amount AS order_amount,o.details AS order_details,o.provider_id';
const stageSQL="CASE WHEN o.status='paid' AND v.stage IN ('payment','pix','paid') THEN 'paid' WHEN o.status='pending' AND o.provider_id IS NOT NULL AND v.stage IN ('payment','pix','paid') THEN 'pix' WHEN v.stage IN ('pix','paid') THEN 'payment' ELSE v.stage END";

function sanitizeCart(lines){
 if(lines===undefined)return null;
 if(!Array.isArray(lines)||lines.length>30)throw new HttpError('Carrinho inválido.');
 const merged=new Map();
 for(const line of lines){
  const p=catalog.get(String(line?.id));
  if(!p||line.plan||!Number.isInteger(line.qty)||line.qty<1||line.qty>p.max)throw new HttpError('Carrinho inválido.');
  const opt=typeof line.opt==='string'?line.opt:'';
  if(opt&&!(p.options||[]).flatMap(o=>o.values||[]).includes(opt))throw new HttpError('Opção inválida.');
  const key=p.id+'|'+opt,qty=(merged.get(key)?.quantity||0)+line.qty;
  if(qty>p.max)throw new HttpError('Quantidade inválida.');
  merged.set(key,{id:p.id,title:p.title+(opt?' — '+opt:''),quantity:qty,unitPrice:p.price});
 }
 return [...merged.values()].sort((a,b)=>a.id.localeCompare(b.id)||a.title.localeCompare(b.title));
}
export async function recordVisit(request,env,id,body){
 const now=Date.now(),stage=body.stage||(/^\/checkout\//.test(body.path)?'details':/^\/cart\//.test(body.path)?'cart':/^\/products\//.test(body.path)?'product':'browsing');
 if(!stages.includes(stage))throw new HttpError('Etapa inválida.');
 const session=request.headers.get('Cookie')?.match(/(?:^|;\s*)sheik_checkout=([a-f0-9-]{72})(?:;|$)/)?.[1];
 const previous=await env.DB.prepare('SELECT '+fields+' '+joined+' WHERE v.id=?').bind(id).first();
 const items=sanitizeCart(body.cart),cart=items?JSON.stringify(items):previous?.cart_data||'[]';
 const amount=items?items.reduce((sum,p)=>sum+p.unitPrice*p.quantity,0):previous?.cart_value||0;
 let started=amount?(Number(previous?.cart_value)&&!(previous?.order_id&&cart!==previous.cart_data)?Number(previous.cart_started_at):now):(stage==='paid'&&previous?.order_status==='paid'?Number(previous.cart_started_at):0);
 if(body.orderId&&session&&/^SB-[a-f0-9-]{36}$/.test(body.orderId)){
  const own=await env.DB.prepare('SELECT created_at FROM orders WHERE id=? AND session_hash=?').bind(body.orderId,sha(session)).first();
  if(own)started=Number(own.created_at);
 }
 const tracking=body.tracking?JSON.stringify(cleanTracking(body.tracking)):previous?.tracking||'{}';
 const sessionHash=session?sha(session):previous?.session_hash||null;
 // A heartbeat writes at most twice a minute; actual stage/cart changes are immediate.
 if(previous&&now-Number(previous.seen_at)<30000&&previous.path===body.path&&previous.stage===stage&&previous.cart_data===cart&&previous.session_hash===sessionHash&&previous.tracking===tracking&&Number(previous.cart_started_at)===started)return;
 await env.DB.prepare('INSERT INTO online_visitors (id,path,seen_at,stage,session_hash,cart_data,cart_value,cart_started_at,tracking) VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET path=excluded.path,seen_at=excluded.seen_at,stage=excluded.stage,session_hash=excluded.session_hash,cart_data=excluded.cart_data,cart_value=excluded.cart_value,cart_started_at=excluded.cart_started_at,tracking=excluded.tracking').bind(id,body.path,now,stage,sessionHash,cart,amount,started,tracking).run();
}
function visitor(row){
 const order=row.order_details?JSON.parse(row.order_details):null;
 return {id:row.id.slice(0,10),path:row.path,stage:row.effective_stage,seenAt:Number(row.seen_at),customer:order?{name:order.customer.name}:null,items:JSON.parse(row.cart_data),amount:Number(row.order_amount??row.cart_value),hasShipping:!!order,tracking:order?.tracking||JSON.parse(row.tracking),orderId:row.order_id||null,orderStatus:row.order_status||null};
}
export async function visitorReport(env,{abandoned=false,from=0,page=1}={}){
 const now=Date.now(),where=abandoned?"v.seen_at>=? AND v.seen_at<? AND v.cart_value>0 AND (o.status IS NULL OR o.status NOT IN ('paid','refunded','chargedback'))":'v.seen_at>=?';
 const args=abandoned?[Math.max(from,now-30*86400000),now-abandonedAfter]:[now-120000];
 const [count,rows,counts,online]=await Promise.all([
  env.DB.prepare('SELECT COUNT(*) AS count,COALESCE(SUM(COALESCE(o.amount,v.cart_value)),0) AS amount '+joined+' WHERE '+where).bind(...args).first(),
  env.DB.prepare('SELECT '+fields+','+stageSQL+' AS effective_stage '+joined+' WHERE '+where+' ORDER BY v.seen_at DESC,v.id LIMIT 25 OFFSET ?').bind(...args,(page-1)*25).all(),
  env.DB.prepare('SELECT '+stageSQL+' AS stage,COUNT(*) AS count '+joined+' WHERE '+where+' GROUP BY '+stageSQL).bind(...args).all(),
  abandoned?env.DB.prepare('SELECT COUNT(*) AS count FROM online_visitors WHERE seen_at>=?').bind(now-120000).first():null
 ]);
 return {visitors:rows.results.map(visitor),total:Number(count.count),online:Number(online?.count??count.count),amount:Number(count.amount),counts:Object.fromEntries(counts.results.map(r=>[r.stage,Number(r.count)])),page,pageSize:25,updatedAt:now,abandonedAfterMinutes:30,retentionDays:30};
}

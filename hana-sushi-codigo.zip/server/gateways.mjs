import {HttpError} from './security.mjs';
import {credential} from './gateway-settings.mjs';
const bases={umbrellapag:'https://api-gateway.umbrellapag.com/api',sharkpay:'https://api.gatewaypayshark.com.br/v1'};
async function call(env,provider,key,path,body){
 if(!key)throw new HttpError('O serviço de pagamento precisa de configuração.',503);
 const response=await (env.__fetch||fetch)(bases[provider]+path,{method:body?'POST':'GET',headers:{...(provider==='sharkpay'?{Authorization:'Bearer '+key}:{'x-api-key':key,'User-Agent':'UMBRELLAB2B/1.0'}),'Content-Type':'application/json',Accept:'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(25000)});
 let payload;try{payload=await response.json();}catch{throw new HttpError('Resposta inválida do serviço de pagamento.',502);}
 if(!response.ok||payload?.error||!payload||(provider==='umbrellapag'&&!payload.data)){
  const error=new HttpError(response.status===401||response.status===403?'A chave de pagamento não foi aceita pela operadora.':'Não foi possível concluir a solicitação de pagamento.',response.status>=500?502:422);
  error.definitive=response.status>=400&&response.status<500;throw error;
 }
 return provider==='umbrellapag'?payload.data:payload;
}
export async function validateCredential(env,provider,key){
 const data=await call(env,provider,key,provider==='sharkpay'?'/store-info':'/user/transactions?limit=1');
 if(provider==='sharkpay'&&(!data.id||data.status!=='ACTIVE'||data.currency!=='BRL'))throw new HttpError('A conta Sharkpay precisa estar ativa e operar em BRL.');
 return true;
}
function normalizeShark(data,fee){
 const feeCents=fee&&Number.isSafeInteger(data.amount)?Math.round(data.amount*fee.bps/10000)+fee.fixed:null;
 return {...data,paymentMethod:data.method,qrCode:data.data?.copypaste,fee:feeCents!==null&&feeCents<=data.amount?{netAmount:data.amount-feeCents}:undefined};
}
export function gatewayPayload(provider,order,id,env){
 // Privacy: describe the real goods generically, without changing identity, quantities or prices.
 const items=order.items.map(item=>({...item,title:'Produto físico'}));
 if(provider==='umbrellapag')return {amount:order.amount,currency:'BRL',paymentMethod:'PIX',installments:1,customer:order.customer,items,pix:{expiresInDays:1},metadata:JSON.stringify({orderId:id,fulfillment:order.ship}),traceable:true,...(order.clientIp?{ip:order.clientIp}:{}),...(order.address?{shipping:{fee:order.shipping,address:order.address}}:{}),...(env.UMBRELLAPAG_POSTBACK_URL?{postbackUrl:env.UMBRELLAPAG_POSTBACK_URL}:{})};
 const a=order.address||order.pickupAddress;
 if(!a)throw new HttpError('A retirada não está disponível neste momento. Escolha entrega.');
 return {amount:order.amount,currency:'BRL',method:'PIX',description:'Compra de produto físico',externalRef:id,
  payer:{name:order.customer.name,taxId:order.customer.document.number,email:order.customer.email,phone:'+55'+order.customer.phone},
  items:items.map(item=>({name:item.title,quantity:item.quantity,price:item.unitPrice,type:'PHYSICAL'})),
  delivery:{fee:order.shipping,address:{country:'BR',state:a.state,city:a.city,district:a.neighborhood,street:a.street,number:a.streetNumber,complement:a.complement||'',zipCode:a.zipCode}},
  // Sharkpay metadata is a typed seller object, not a free-form map. Its
  // optional omission keeps externalRef as the order link without inventing seller data.
  ...(order.clientIp?{ip:order.clientIp}:{}),...(env.SHARKPAY_POSTBACK_URL?{notificationUrl:env.SHARKPAY_POSTBACK_URL}:{})};
}
export async function createPayment(env,gateway,order,id){const data=await call(env,gateway.provider,gateway.key,gateway.provider==='sharkpay'?'/payment':'/user/transactions',gatewayPayload(gateway.provider,order,id,env));return gateway.provider==='sharkpay'?normalizeShark(data,order.gatewayFee):data;}
export async function findPayment(env,row){const provider=row.provider||'umbrellapag',key=await credential(env,provider,row.credential_id);const data=await call(env,provider,key,(provider==='sharkpay'?'/payment/':'/user/transactions/')+encodeURIComponent(row.provider_id));return provider==='sharkpay'?normalizeShark(data,JSON.parse(row.details).gatewayFee):data;}

# Hana Sushi

Loja independente baseada na referência visual https://seguro-sushis.it.com/ e no backend do projeto SHOPPINGSHEIKBRAS. Catálogo com nove combos, três complementos e sete sobremesas. Imagens e fontes locais. Carrinho persistente, checkout em três etapas, consulta ViaCEP e Pix com confirmação no servidor.

## Integrações

Umbrellapag, Sharkpay, UTMify e painel /adminx reaproveitados e adaptados. Preços calculados no servidor, limite de complementos, uma sobremesa por pedido, frete gratuito, idempotência de cobrança, validação de CPF e confirmação do valor/identidade da transação. O painel mostra pedidos, vendas, UTMs, visitantes e carrinhos abandonados.

As chaves privadas do Shopping não estavam presentes no código local e NÃO foram copiadas. A emissão de Pix fica indisponível até cadastrar uma chave válida no painel. Nenhuma cobrança real foi realizada. O Pixel UTMify público do Shopping está configurado na hospedagem; o token privado de vendas ainda precisa ser cadastrado.

## Acesso

A loja é pública e abre sem login. O painel /adminx usa usuário e senha próprios, com sessão de 8 horas em cookie HttpOnly, limitação de tentativas e proteção de origem. O acesso inicial é entregue em arquivo separado, fora do código e da publicação. Não é necessário entrar no ChatGPT.

## Segredos de produção

SETTINGS_ENCRYPTION_KEY: chave de 32 bytes em hexadecimal usada para criptografar as credenciais salvas pelo painel; já preparada na hospedagem. Não troque sem migrar as chaves criptografadas.
ADMIN_USERNAME: nome de usuário do painel.
ADMIN_PASSWORD_HASH: hash scrypt da senha, configurado como segredo.
PUBLIC_STORE_ORIGINS: origens HTTPS exatas das lojas externas autorizadas a usar este backend por proxy. Sem curingas. A loja Netlify usa o mesmo banco e APIs desta hospedagem, que precisa permanecer ativa.
UMBRELLAPAG_API_KEY ou SHARKPAY_API_KEY: opcionalmente cadastrar pelo ambiente em vez do painel.
UTMIFY_API_TOKEN: token privado de envio das vendas.
UTMIFY_PIXEL_ID: identificador público do pixel.
UMBRELLAPAG_WEBHOOK_SECRET e UMBRELLAPAG_POSTBACK_URL: callback próprio em /api/umbrellapag/webhook?token=SEGREDO.
SHARKPAY_WEBHOOK_SECRET e SHARKPAY_POSTBACK_URL: callback próprio em /api/sharkpay/webhook?token=SEGREDO.

Webhooks de operadoras usam a URL pública da loja e o segredo configurado para cada callback. Não compartilhe chaves em mensagens nem as coloque em arquivos públicos.

## Banco e testes

Cloudflare D1 com migração Drizzle. Bancos e pedidos do Shopping não foram importados. A fila UTMify tenta o envio nas atualizações do pedido e é reprocessada no acesso administrativo; esta versão não tem a tarefa agendada Netlify do projeto original.

npm run dev
npm run build
node --test server/payments.test.mjs server/sushi.test.mjs
node node_modules/typescript/bin/tsc --noEmit

Os testes usam operadoras simuladas e não geram cobranças reais. Para desenvolvimento, use .dev.vars ignorado pelo Git. Aplique a migração SQL local antes de testar as APIs.

## Conteúdo a revisar antes de abrir a loja

Conferir identidade da empresa, telefone de atendimento, área e prazo reais de entrega, composição dos combos, preços e termos. A referência não forneceu comprovação de distância, avaliações ou estoque; contadores artificiais, avaliações e CNPJ da referência não foram transferidos para esta loja.

A implementação preserva imagens, paleta, cardápio e estrutura principal, mas não é uma cópia pixel a pixel. O painel mantém a estrutura do Shopping com a marca Hana Sushi. As descrições detalhadas, exceto a do Combo Satori, foram resumidas a partir dos nomes dos produtos.

## Cidade automática

Na página inicial, o navegador consulta https://ipwho.is/ por HTTPS para estimar cidade e UF pelo IP do próprio visitante, sem login ou GPS. Somente cidade e UF são aproveitados. A seleção automática fica em cache por 6 horas; uma correção manual permanece até nova detecção ou alteração. Falhas, bloqueadores, respostas fora do Brasil e limites de uso deixam a escolha manual disponível. O endereço do checkout continua sendo preenchido pelo CEP, sem ser substituído pela estimativa de IP.

A API gratuita permite uso comercial e tem limite compartilhado de 1.000 consultas diárias por domínio, sem SLA. Para volumes maiores, contratar e integrar um plano adequado. Documentação: https://ipwhois.io/documentation.

Teste da localização: node --test server/location.test.mjs

A consulta começa no cabeçalho HTML, antes do carregamento do aplicativo, e a mesma resposta é reaproveitada pelo React. Uma cidade válida no cache evita nova consulta; o limite de espera da rede é de 3 segundos. O seletor não exibe botão de detecção nem aviso de localização aproximada. Falhas mantêm o preenchimento manual disponível.

Ao abrir o cardápio pela primeira vez, a seleção começa pelo estado detectado. O visitante confirma o estado, depois a cidade e entra no cardápio. A confirmação é lembrada no navegador. Ao trocar o estado, a cidade anterior é limpa para não combinar localidades de estados diferentes. A edição manual tem prioridade sobre uma detecção que ainda esteja em andamento.

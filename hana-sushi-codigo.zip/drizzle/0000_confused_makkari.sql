CREATE TABLE `admin_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`action` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `admin_owner` (
	`id` integer PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`created_at` integer NOT NULL,
	CONSTRAINT "single_owner" CHECK("admin_owner"."id"=1)
);
--> statement-breakpoint
CREATE TABLE `admin_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`auth_version` text NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `admin_sessions_expiry` ON `admin_sessions` (`expires_at`);--> statement-breakpoint
CREATE TABLE `gateway_credentials` (
	`id` text PRIMARY KEY NOT NULL,
	`provider` text NOT NULL,
	`secret` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `online_visitors` (
	`id` text PRIMARY KEY NOT NULL,
	`path` text NOT NULL,
	`seen_at` integer NOT NULL,
	`stage` text DEFAULT 'browsing' NOT NULL,
	`session_hash` text,
	`cart_data` text DEFAULT '[]' NOT NULL,
	`cart_value` integer DEFAULT 0 NOT NULL,
	`cart_started_at` integer DEFAULT 0 NOT NULL,
	`tracking` text DEFAULT '{}' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `online_visitors_seen` ON `online_visitors` (`seen_at`);--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`session_hash` text NOT NULL,
	`request_key` text NOT NULL,
	`request_hash` text NOT NULL,
	`provider_id` text,
	`provider_status` text,
	`status` text NOT NULL,
	`amount` integer NOT NULL,
	`details` text NOT NULL,
	`pix_code` text,
	`expires_at` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	`checked_at` integer NOT NULL,
	`approved_at` integer,
	`refunded_at` integer,
	`fee_cents` integer,
	`utmify_sent_status` text,
	`utmify_attempts` integer DEFAULT 0 NOT NULL,
	`utmify_next_attempt` integer DEFAULT 0 NOT NULL,
	`utmify_lock_until` integer DEFAULT 0 NOT NULL,
	`provider` text DEFAULT 'umbrellapag' NOT NULL,
	`credential_id` text,
	`utm_source` text,
	`utm_campaign` text,
	`parent_order_id` text,
	`root_order_id` text,
	FOREIGN KEY (`parent_order_id`) REFERENCES `orders`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`root_order_id`) REFERENCES `orders`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `orders_request_unique` ON `orders` (`session_hash`,`request_key`);--> statement-breakpoint
CREATE UNIQUE INDEX `orders_provider_unique` ON `orders` (`provider`,`provider_id`);--> statement-breakpoint
CREATE INDEX `orders_session_created` ON `orders` (`session_hash`,`created_at`);--> statement-breakpoint
CREATE INDEX `orders_utmify_queue` ON `orders` (`utmify_next_attempt`,`created_at`);--> statement-breakpoint
CREATE INDEX `orders_created` ON `orders` (`created_at`);--> statement-breakpoint
CREATE INDEX `orders_purchase_group` ON `orders` (`root_order_id`,`created_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `orders_one_addition` ON `orders` (`parent_order_id`) WHERE "orders"."parent_order_id" IS NOT NULL AND "orders"."status"<>'failed';--> statement-breakpoint
CREATE TABLE `request_limits` (
	`id` text PRIMARY KEY NOT NULL,
	`window_start` integer NOT NULL,
	`hits` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `shop_settings` (
	`id` integer PRIMARY KEY NOT NULL,
	`value` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	CONSTRAINT "single_settings" CHECK("shop_settings"."id"=1)
);

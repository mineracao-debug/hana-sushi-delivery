ALTER TABLE `orders` ADD `fulfillment_status` text DEFAULT 'preparing' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `fulfillment_version` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `dispatched_at` integer;--> statement-breakpoint
ALTER TABLE `orders` ADD `delivered_at` integer;